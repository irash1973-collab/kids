const { chromium } = require('playwright');
(async()=>{
 const b=await chromium.launch(); const pg=await b.newPage();
 const errs=[]; pg.on('pageerror',e=>errs.push('PAGEERR '+e.message)); pg.on('console',m=>{if(m.type()==='error')errs.push('CONSOLE '+m.text())});
 await pg.goto('file:///home/claude/kids/index.html'); await pg.waitForTimeout(500);
 const res = await pg.evaluate(()=>{
  const T=window.__T, out={book:null,gen:{},demo:[],tasks:{}};
  T.buildBook(); out.book=T.bad();
  // pieces
  ['R','B','Q','N','K','P'].forEach(c=>{ let fail=[]; for(let lv=1;lv<=20;lv++){ const t0=performance.now(); const ex=T.genPiece(c,lv); const dt=performance.now()-t0; if(!ex) fail.push(lv); else if(!(ex.opt>=1)) fail.push('opt'+lv); if(dt>300) fail.push('slow'+lv+':'+Math.round(dt)); } out.gen[c]=fail; });
  // demos
  T.GROUPS.forEach(g=>g.ids.forEach(id=>{ const L=T.LESS[id]; (L.slides||[]).forEach((s,i)=>{ if(!s.demo) return; let pos=T.E.fromFEN(s.demo.fen||'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'); let i2=0; for(const st of s.demo.steps){ const u=st.split('|')[0]; const m=T.uciMove(pos,u); if(!m){ out.demo.push(id+'#'+i+' bad move '+u+' at '+i2); break;} pos=T.E.make(pos,m); i2++; } out.demo.push(id+'#'+i+' end:'+T.E.status(pos)); }); }));
  return out;
 });
 console.log(JSON.stringify(res,null,1)); console.log(errs.join('\n')); await b.close();
})();
