var E=require('./engine.js');
function T(fen,ms,d){var p=E.fromFEN(fen);E.clear();var t=Date.now();var r=E.think(p,{ms:ms,depth:d||12});var m=r.move;
 console.log(fen.slice(0,30),'->','abcdefgh'[m.f%8]+(8-(m.f>>3))+'abcdefgh'[m.t%8]+(8-(m.t>>3)),'score',r.score,'d',r.depth,'nodes',r.nodes,(Date.now()-t)+'ms');}
// mate in 2: Qh5+? use known: 
T('r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4',1500); // Qxf7#
T('6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1',1000); // Rd8#
T('r2qkb1r/pp2nppp/3p4/2pNN1B1/2BnP3/3P4/PPP2PPP/R2bK2R w KQkq - 1 1',2000); // Nf6+ gxf6 Bxf7#
T('4k3/8/4K3/8/8/8/8/R7 w - - 0 1',1000);
T('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',1500);
T('r1b2rk1/pp1nqppp/2p1pn2/3p4/2PP4/2NBPN2/PP3PPP/R2QK2R w KQ - 0 1',1500);
