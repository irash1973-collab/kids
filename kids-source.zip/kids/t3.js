var E=require('./engine.js');
['R','Q','B','N','P','X'].forEach(function(k){var t=Date.now(),n=0,mx=0;for(var i=0;i<30;i++){var t0=Date.now();var p=E.genPuzzle(k);mx=Math.max(mx,Date.now()-t0);if(p)n++;}
console.log(k,n,'/30',(Date.now()-t)+'ms total, max',mx,'ms',E.genPuzzle(k).fen);});
