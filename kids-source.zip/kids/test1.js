const { chromium } = require('playwright');
(async () => {
  const br = await chromium.launch();
  const pg = await br.newPage({ viewport: { width: 400, height: 900 } });
  const errs = []; pg.on('pageerror', e => errs.push('PAGEERR '+e.message)); pg.on('console', m => m.type()==='error' && errs.push(m.text()));
  const url = 'file://' + process.cwd() + '/index.html';
  await pg.goto(url); await pg.screenshot({ path: 'home.png', fullPage: true });
  // puzzles: all kinds
  await pg.goto(url + '#puzzles'); await pg.waitForSelector('.sq');
  for (const k of ['R','Q','B','N','P','X','C']) {
    await pg.click('#kinds button[data-k="'+k+'"]');
    await pg.waitForTimeout(100);
    // solve via engine on current board FEN? derive from window: use hint button & click
    await pg.click('#hintBtn');
    const fromSq = await pg.$eval('.sq.hint', e => +e.dataset.i);
    // find mating target by clicking piece, then try each target
    await pg.click('.sq[data-i="'+fromSq+'"]');
    const tg = await pg.$$eval('.sq.tg', e => e.map(x => +x.dataset.i));
    let ok = false;
    for (const t of tg) {
      await pg.click('.sq[data-i="'+t+'"]');
      const m = await pg.textContent('#msg');
      if (/^Мат/.test(m)) { ok = true; break; }
      await pg.waitForTimeout(1600); await pg.click('.sq[data-i="'+fromSq+'"]');
    }
    console.log(k, 'solved', ok, await pg.textContent('#cnt'));
    await pg.screenshot({ path: 'pz_'+k+'.png' });
    // close any modal
    const md = await pg.$('#modal'); if (md) { await pg.waitForTimeout(800); const b = await pg.$('#modal [data-act]'); if (b) await b.click(); }
  }
  await pg.goto(url + '#play'); await pg.waitForSelector('.wcard');
  await pg.screenshot({ path: 'worlds.png', fullPage: true });
  await pg.goto(url + '#play/1'); await pg.waitForSelector('.lvbtn');
  await pg.screenshot({ path: 'world1.png', fullPage: true });
  await pg.click('.lvbtn[data-l="1"]'); await pg.waitForSelector('.sq');
  // play human using strong engine
  let n = 0;
  while (n < 150) {
    const st = await pg.evaluate(() => ({ over: __G.over, busy: __G.busy }));
    if (st.over) break;
    if (st.busy) { await pg.waitForTimeout(150); continue; }
    const mv = await pg.evaluate(() => { const r = Eng.think(__G.pos, {depth:4, ms:200}); return r.move; });
    await pg.click('.sq[data-i="'+mv.f+'"]'); await pg.click('.sq[data-i="'+mv.t+'"]');
    const promo = await pg.$('#promo:not([hidden]) button'); if (promo) await promo.click();
    n++; await pg.waitForTimeout(250);
  }
  console.log('game over after', n, await pg.textContent('#msg'));
  await pg.waitForTimeout(1500);
  await pg.screenshot({ path: 'win.png' });
  const hasModal = await pg.$('#modal'); console.log('modal', !!hasModal);
  if (hasModal) { await pg.click('#modal [data-act="an"]'); await pg.waitForSelector('#rvPrev', {timeout: 120000}); await pg.waitForTimeout(500); await pg.screenshot({ path: 'review.png', fullPage: true }); console.log(await pg.textContent('#msg')); }
  await pg.goto(url + '#awards'); await pg.screenshot({ path: 'awards.png', fullPage: true });
  console.log('errors:', errs.filter(e=>!/fonts|ERR_|Failed to load/i.test(e)));
  await br.close();
})();
