const { chromium } = require('playwright');
(async()=>{
 const b=await chromium.launch(); const pg=await b.newPage({viewport:{width:420,height:900}}); const errs=[];
 pg.on('pageerror',e=>errs.push('PAGEERR '+e.message));
 await pg.goto('file:///home/claude/kids/index.html#lessons'); await pg.waitForTimeout(500);
 await pg.screenshot({path:'c_lessons.png',fullPage:true});
 // slides lesson
 await pg.goto('file:///home/claude/kids/index.html#lesson/history'); await pg.waitForTimeout(300);
 await pg.screenshot({path:'c_hist.png'});
 await pg.goto('file:///home/claude/kids/index.html#lesson/pR'); await pg.waitForTimeout(300);
 await pg.click('#sNext'); await pg.waitForTimeout(200);
 await pg.screenshot({path:'c_free.png',fullPage:true});
 // piece exercise: solve via answer
 await pg.goto('file:///home/claude/kids/index.html#lesson/pR/3'); await pg.waitForTimeout(300);
 await pg.screenshot({path:'c_ex.png',fullPage:true});
 await pg.click('#hintB'); await pg.waitForTimeout(200);
 // play optimal by clicking hint repeatedly
 for(let k=0;k<12;k++){ const done=await pg.$('#again'); if(done) break; await pg.click('#hintB'); await pg.waitForTimeout(100); const tg=await pg.$$('.sq.tg'); if(!tg.length) break; await tg[0].click(); await pg.waitForTimeout(150);}
 await pg.screenshot({path:'c_done.png',fullPage:true});
 console.log('pts', await pg.textContent('#pts'));
 // names
 await pg.goto('file:///home/claude/kids/index.html#lesson/squares/12'); await pg.waitForTimeout(300);
 await pg.screenshot({path:'c_names.png',fullPage:true});
 // task
 await pg.goto('file:///home/claude/kids/index.html#lesson/check/9'); await pg.waitForTimeout(500);
 await pg.screenshot({path:'c_task.png',fullPage:true});
 await pg.click('#ansB'); await pg.waitForTimeout(1800);
 await pg.screenshot({path:'c_task2.png',fullPage:true});
 console.log('msg', await pg.textContent('#msg'));
 // yes/no
 await pg.goto('file:///home/claude/kids/index.html#lesson/castle/10'); await pg.waitForTimeout(400);
 await pg.screenshot({path:'c_yn.png',fullPage:true});
 // maze pawn
 await pg.goto('file:///home/claude/kids/index.html#lesson/pP/14'); await pg.waitForTimeout(400);
 await pg.screenshot({path:'c_pawn.png',fullPage:true});
 // demo slide
 await pg.goto('file:///home/claude/kids/index.html#lesson/traps'); await pg.waitForTimeout(300);
 await pg.click('#sNext'); await pg.waitForTimeout(200); await pg.click('#dNext'); await pg.click('#dNext'); await pg.click('#dNext'); await pg.waitForTimeout(300);
 await pg.screenshot({path:'c_demo.png',fullPage:true});
 console.log(errs.join('\n')); await b.close();
})();
