const { chromium } = require('playwright');
(async()=>{
 const b=await chromium.launch(); const pg=await b.newPage(); const errs=[];
 pg.on('pageerror',e=>errs.push('PAGEERR '+e.message));
 await pg.goto('file:///home/claude/kids/index.html'); await pg.waitForTimeout(400);
 const res = await pg.evaluate(()=>{
  const T=window.__T, out={fails:[],slow:[],demo:[],p13:null};
  ['P'].forEach(c=>{ for(let lv=1;lv<=20;lv++){const ex=T.genPiece(c,lv); if(!ex) out.fails.push('P'+lv);} });
  ['check','mate','stalemate','ep','promo','castle','baby'].forEach(id=>{
    const L=T.LESS[id];
    for(let lv=1;lv<=L.levels;lv++){ for(let rep=0;rep<5;rep++){
      const r=T.mkRng(lv*131+rep*7919); const t0=performance.now(); let g; try{ g=L.gen(lv,r);}catch(e){ out.fails.push(id+lv+' EXC '+e.message); continue; }
      const dt=performance.now()-t0; if(dt>800) out.slow.push(id+lv+':'+Math.round(dt));
      if(!g){ out.fails.push(id+lv+' null'); continue; }
      if(g.q){ continue; }
      const pos=g.pos; const mv=T.E.legal(pos); const okm=mv.filter(m=>g.ok? g.ok(m,pos,T.E.make(pos,m)) : true);
      if(!okm.length) out.fails.push(id+lv+' no-sol');
    } }
  });
  T.GROUPS.forEach(g=>g.ids.forEach(id=>{ const L=T.LESS[id]; (L.slides||[]).forEach((s,i)=>{ if(!s.demo) return; let pos=T.E.fromFEN(s.demo.fen||'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'); for(const st of s.demo.steps){ const m=T.uciMove(pos,st.split('|')[0]); if(!m){ out.demo.push(id+'#'+i+' BAD '+st); break;} pos=T.E.make(pos,m);} }); }));
  // castle yes/no answers
  const cq=[]; const L=T.LESS.castle; for(let lv=9;lv<=20;lv++){ const g=L.gen(lv,T.mkRng(1)); cq.push((g.ans?'Y':'N')); } out.castle=cq.join('');
  return out;
 });
 console.log(JSON.stringify(res)); console.log(errs.join('\n')); await b.close();
})();
