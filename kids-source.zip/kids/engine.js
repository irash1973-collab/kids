var Eng = (function () {
  var P = 1, N = 2, B = 3, R = 4, Q = 5, K = 6;
  var VAL = [0, 100, 320, 330, 500, 900, 20000];
  var MATE = 100000;
  var OFF = {
    N: [[1,2],[2,1],[-1,2],[-2,1],[1,-2],[2,-1],[-1,-2],[-2,-1]],
    K: [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]],
    R: [[1,0],[-1,0],[0,1],[0,-1]],
    B: [[1,1],[1,-1],[-1,1],[-1,-1]]
  };
  var PST = [null,
    [0,0,0,0,0,0,0,0, 50,50,50,50,50,50,50,50, 10,10,20,30,30,20,10,10, 5,5,10,25,25,10,5,5, 0,0,0,20,20,0,0,0, 5,-5,-10,0,0,-10,-5,5, 5,10,10,-20,-20,10,10,5, 0,0,0,0,0,0,0,0],
    [-50,-40,-30,-30,-30,-30,-40,-50, -40,-20,0,0,0,0,-20,-40, -30,0,10,15,15,10,0,-30, -30,5,15,20,20,15,5,-30, -30,0,15,20,20,15,0,-30, -30,5,10,15,15,10,5,-30, -40,-20,0,5,5,0,-20,-40, -50,-40,-30,-30,-30,-30,-40,-50],
    [-20,-10,-10,-10,-10,-10,-10,-20, -10,0,0,0,0,0,0,-10, -10,0,5,10,10,5,0,-10, -10,5,5,10,10,5,5,-10, -10,0,10,10,10,10,0,-10, -10,10,10,10,10,10,10,-10, -10,5,0,0,0,0,5,-10, -20,-10,-10,-10,-10,-10,-10,-20],
    [0,0,0,0,0,0,0,0, 5,10,10,10,10,10,10,5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, 0,0,0,5,5,0,0,0],
    [-20,-10,-10,-5,-5,-10,-10,-20, -10,0,0,0,0,0,0,-10, -10,0,5,5,5,5,0,-10, -5,0,5,5,5,5,0,-5, 0,0,5,5,5,5,0,-5, -10,5,5,5,5,5,0,-10, -10,0,5,0,0,0,0,-10, -20,-10,-10,-5,-5,-10,-10,-20],
    [-30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30, -20,-30,-30,-40,-40,-30,-30,-20, -10,-20,-20,-20,-20,-20,-20,-10, 20,20,0,0,0,0,20,20, 20,30,10,0,0,10,30,20]
  ];

  function fromFEN(fen) {
    var parts = fen.split(' ');
    var b = new Int8Array(64);
    var map = { p: P, n: N, b: B, r: R, q: Q, k: K };
    parts[0].split('/').forEach(function (row, y) {
      var x = 0;
      row.split('').forEach(function (ch) {
        if (/\d/.test(ch)) x += +ch;
        else { var low = ch.toLowerCase(); b[y * 8 + x] = (ch === low ? -1 : 1) * map[low]; x++; }
      });
    });
    var cs = parts[2] || '-', c = 0;
    if (cs.indexOf('K') >= 0) c |= 1; if (cs.indexOf('Q') >= 0) c |= 2;
    if (cs.indexOf('k') >= 0) c |= 4; if (cs.indexOf('q') >= 0) c |= 8;
    var ep = -1;
    if (parts[3] && parts[3] !== '-') ep = (8 - +parts[3][1]) * 8 + (parts[3].charCodeAt(0) - 97);
    return { b: b, turn: (parts[1] || 'w') === 'w' ? 1 : -1, castle: c, ep: ep, half: +(parts[4] || 0) };
  }
  function start() { return fromFEN('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'); }

  function attacked(b, sq, by) {
    var x = sq & 7, y = sq >> 3, i, d, nx, ny, v;
    var py = by === 1 ? y + 1 : y - 1;
    if (py >= 0 && py < 8) {
      if (x > 0 && b[py * 8 + x - 1] === by * P) return true;
      if (x < 7 && b[py * 8 + x + 1] === by * P) return true;
    }
    for (i = 0; i < 8; i++) {
      d = OFF.N[i]; nx = x + d[0]; ny = y + d[1];
      if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8 && b[ny * 8 + nx] === by * N) return true;
      d = OFF.K[i]; nx = x + d[0]; ny = y + d[1];
      if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8 && b[ny * 8 + nx] === by * K) return true;
    }
    for (i = 0; i < 8; i++) {
      d = OFF.K[i]; nx = x + d[0]; ny = y + d[1];
      var diag = i >= 4;
      while (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) {
        v = b[ny * 8 + nx];
        if (v) {
          if (v === by * Q || v === by * (diag ? B : R)) return true;
          break;
        }
        nx += d[0]; ny += d[1];
      }
    }
    return false;
  }

  function kingSq(b, c) { for (var i = 0; i < 64; i++) if (b[i] === c * K) return i; return -1; }
  function inCheck(pos) { var k = kingSq(pos.b, pos.turn); return k >= 0 && attacked(pos.b, k, -pos.turn); }

  function pseudo(pos, capsOnly) {
    var b = pos.b, t = pos.turn, out = [], i, j, x, y, v, a, d, nx, ny;
    for (i = 0; i < 64; i++) {
      v = b[i];
      if (!v || (v > 0) !== (t > 0)) continue;
      a = v * t; x = i & 7; y = i >> 3;
      if (a === P) {
        var dy = -t, ny1 = y + dy, last = (t === 1 ? 0 : 7), sy = (t === 1 ? 6 : 1);
        if (!capsOnly || ny1 === last) {
          if (!b[ny1 * 8 + x]) {
            if (ny1 === last) { [Q, R, B, N].forEach(function (p) { out.push({ f: i, t: ny1 * 8 + x, p: p, fl: 0 }); }); }
            else {
              out.push({ f: i, t: ny1 * 8 + x, p: 0, fl: 0 });
              if (!capsOnly && y === sy && !b[(y + 2 * dy) * 8 + x]) out.push({ f: i, t: (y + 2 * dy) * 8 + x, p: 0, fl: 0 });
            }
          }
        }
        [-1, 1].forEach(function (dx) {
          var cx = x + dx; if (cx < 0 || cx > 7) return;
          var to = ny1 * 8 + cx, tv = b[to];
          if (tv && (tv > 0) !== (t > 0)) {
            if (ny1 === last) { [Q, R, B, N].forEach(function (p) { out.push({ f: i, t: to, p: p, fl: 0 }); }); }
            else out.push({ f: i, t: to, p: 0, fl: 0 });
          } else if (to === pos.ep) out.push({ f: i, t: to, p: 0, fl: 1 });
        });
      } else if (a === N || a === K) {
        var offs = a === N ? OFF.N : OFF.K;
        for (j = 0; j < 8; j++) {
          nx = x + offs[j][0]; ny = y + offs[j][1];
          if (nx < 0 || nx > 7 || ny < 0 || ny > 7) continue;
          var tv2 = b[ny * 8 + nx];
          if (tv2 && (tv2 > 0) === (t > 0)) continue;
          if (capsOnly && !tv2) continue;
          out.push({ f: i, t: ny * 8 + nx, p: 0, fl: 0 });
        }
        if (a === K && !capsOnly) {
          var home = t === 1 ? 60 : 4;
          if (i === home && !attacked(b, home, -t)) {
            var ks = t === 1 ? 1 : 4, qs = t === 1 ? 2 : 8;
            if ((pos.castle & ks) && b[home + 3] === t * R && !b[home + 1] && !b[home + 2] && !attacked(b, home + 1, -t) && !attacked(b, home + 2, -t))
              out.push({ f: i, t: home + 2, p: 0, fl: 2 });
            if ((pos.castle & qs) && b[home - 4] === t * R && !b[home - 1] && !b[home - 2] && !b[home - 3] && !attacked(b, home - 1, -t) && !attacked(b, home - 2, -t))
              out.push({ f: i, t: home - 2, p: 0, fl: 2 });
          }
        }
      } else {
        var ds = a === R ? OFF.R : a === B ? OFF.B : OFF.K;
        for (j = 0; j < ds.length; j++) {
          d = ds[j]; nx = x + d[0]; ny = y + d[1];
          while (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) {
            var tv3 = b[ny * 8 + nx];
            if (tv3) { if ((tv3 > 0) !== (t > 0)) out.push({ f: i, t: ny * 8 + nx, p: 0, fl: 0 }); break; }
            if (!capsOnly) out.push({ f: i, t: ny * 8 + nx, p: 0, fl: 0 });
            nx += d[0]; ny += d[1];
          }
        }
      }
    }
    return out;
  }

  function make(pos, m) {
    var b = pos.b.slice(), t = pos.turn, v = b[m.f], a = v * t, cap = b[m.t];
    var castle = pos.castle, ep = -1, half = pos.half + 1;
    b[m.t] = v; b[m.f] = 0;
    if (m.fl === 1) { b[(m.f >> 3) * 8 + (m.t & 7)] = 0; }
    if (m.fl === 2) {
      if (m.t > m.f) { b[m.f + 1] = b[m.f + 3]; b[m.f + 3] = 0; } else { b[m.f - 1] = b[m.f - 4]; b[m.f - 4] = 0; }
    }
    if (m.p) b[m.t] = t * m.p;
    if (a === P || cap) half = 0;
    if (a === K) castle &= (t === 1 ? ~3 : ~12);
    if (m.f === 63 || m.t === 63) castle &= ~1;
    if (m.f === 56 || m.t === 56) castle &= ~2;
    if (m.f === 7 || m.t === 7) castle &= ~4;
    if (m.f === 0 || m.t === 0) castle &= ~8;
    if (a === P && Math.abs(m.t - m.f) === 16) {
      var mid = (m.f + m.t) >> 1, tx = m.t & 7, row = m.t >> 3;
      if ((tx > 0 && b[row * 8 + tx - 1] === -t * P) || (tx < 7 && b[row * 8 + tx + 1] === -t * P)) ep = mid;
    }
    return { b: b, turn: -t, castle: castle, ep: ep, half: half };
  }

  function legal(pos) {
    var ms = pseudo(pos, false), res = [], k, t = pos.turn;
    for (var i = 0; i < ms.length; i++) {
      var np = make(pos, ms[i]);
      k = kingSq(np.b, t);
      if (k >= 0 && !attacked(np.b, k, -t)) res.push(ms[i]);
    }
    return res;
  }

  function status(pos) {
    var has = legal(pos).length > 0, chk = inCheck(pos);
    if (!has) return chk ? 'mate' : 'stalemate';
    return chk ? 'check' : 'ok';
  }

  function key(pos) { return pos.b.join(',') + '|' + pos.turn + pos.castle + pos.ep; }

  function insufficient(pos) {
    var minors = 0;
    for (var i = 0; i < 64; i++) {
      var a = Math.abs(pos.b[i]);
      if (a === P || a === R || a === Q) return false;
      if (a === N || a === B) minors++;
    }
    return minors <= 1;
  }

  /* ===== Простая оценка и поиск для слабых роботов (уровни 1-20) ===== */
  function evalSimple(pos) {
    var b = pos.b, s = 0, i, v, a, w = 0, bl = 0, wk = -1, bk = -1;
    for (i = 0; i < 64; i++) {
      v = b[i]; if (!v) continue;
      a = v > 0 ? v : -v;
      if (v > 0) { s += VAL[a] + PST[a][i]; if (a === K) wk = i; else if (a !== P) w += VAL[a]; }
      else { s -= VAL[a] + PST[a][i ^ 56]; if (a === K) bk = i; else if (a !== P) bl += VAL[a]; }
    }
    if (w + bl < 1400 && wk >= 0 && bk >= 0) {
      var cd = function (sq) { var x = sq & 7, y = sq >> 3; return Math.abs(x - 3.5) + Math.abs(y - 3.5); };
      s += (cd(bk) - cd(wk)) * 8;
      var kd = Math.abs((wk & 7) - (bk & 7)) + Math.abs((wk >> 3) - (bk >> 3));
      if (w > bl + 200) s += (14 - kd) * 6 + cd(bk) * 12;
      if (bl > w + 200) s -= (14 - kd) * 6 + cd(wk) * 12;
    }
    return s * pos.turn;
  }
  function worder(pos, ms) {
    var b = pos.b;
    for (var i = 0; i < ms.length; i++) {
      var m = ms[i], c = b[m.t], sc = 0;
      if (c) sc = 10 * VAL[c > 0 ? c : -c] - VAL[Math.abs(b[m.f])] / 10 + 1000;
      if (m.p) sc += VAL[m.p];
      m.s = sc;
    }
    ms.sort(function (a, c2) { return c2.s - a.s; });
    return ms;
  }
  function wqs(pos, alpha, beta, ply, ctx) {
    if ((++ctx.nodes & 1023) === 0 && Date.now() > ctx.deadline) ctx.stop = true;
    if (ctx.stop) return 0;
    var stand = evalSimple(pos);
    if (stand >= beta) return stand;
    if (ply > 5) return stand;
    if (stand > alpha) alpha = stand;
    var ms = worder(pos, pseudo(pos, true)), t = pos.turn;
    for (var i = 0; i < ms.length; i++) {
      var np = make(pos, ms[i]), k = kingSq(np.b, t);
      if (k < 0 || attacked(np.b, k, -t)) continue;
      var sc = -wqs(np, -beta, -alpha, ply + 1, ctx);
      if (ctx.stop) return 0;
      if (sc >= beta) return sc;
      if (sc > alpha) alpha = sc;
    }
    return alpha;
  }
  function wsearch(pos, depth, alpha, beta, ply, ctx) {
    if ((++ctx.nodes & 1023) === 0 && Date.now() > ctx.deadline) ctx.stop = true;
    if (ctx.stop) return 0;
    if (depth <= 0) return ctx.q ? wqs(pos, alpha, beta, 0, ctx) : evalSimple(pos);
    var ms = legal(pos);
    if (!ms.length) return inCheck(pos) ? -MATE + ply : 0;
    if (pos.half >= 100) return 0;
    worder(pos, ms);
    var best = -Infinity;
    for (var i = 0; i < ms.length; i++) {
      var sc = -wsearch(make(pos, ms[i]), depth - 1, -beta, -alpha, ply + 1, ctx);
      if (ctx.stop) return 0;
      if (sc > best) best = sc;
      if (sc > alpha) alpha = sc;
      if (alpha >= beta) break;
    }
    return best;
  }
  function gauss() { var u = Math.random() || 1e-9, v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
  function weakMove(pos, level, cfg) {
    var ms = legal(pos);
    if (!ms.length) return null;
    if (cfg.noise >= 9999) return ms[Math.floor(Math.random() * ms.length)];
    if (level >= 4 || Math.random() < 0.3) {
      for (var i = 0; i < ms.length; i++) { if (status(make(pos, ms[i])) === 'mate') return ms[i]; }
    }
    var ctx = { nodes: 0, stop: false, q: cfg.q, deadline: Date.now() + cfg.ms };
    var result = null;
    for (var d = 1; d <= cfg.depth; d++) {
      var scores = [], full = true;
      worder(pos, ms);
      for (var j = 0; j < ms.length; j++) {
        var sc = -wsearch(make(pos, ms[j]), d - 1, -Infinity, Infinity, 1, ctx);
        if (ctx.stop) { full = false; break; }
        scores.push(sc);
      }
      if (!full) break;
      result = scores.slice();
    }
    if (!result) result = ms.map(function () { return Math.random(); });
    var bi = 0, bs = -Infinity;
    for (var k2 = 0; k2 < ms.length; k2++) {
      var s2 = result[k2] + (cfg.noise ? gauss() * cfg.noise : 0);
      if (s2 > bs) { bs = s2; bi = k2; }
    }
    return ms[bi];
  }

  /* ===== Сильный движок: хеш Цобриста, таблица, углубление, PVS, нулевой ход, LMR, тихий поиск ===== */
  var seed = 123456789;
  function rnd() { seed = (seed + 0x6D2B79F5) | 0; var t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return (t ^ (t >>> 14)) | 0; }
  var Z1 = new Int32Array(13 * 64), Z2 = new Int32Array(13 * 64), ZC1 = new Int32Array(16), ZC2 = new Int32Array(16), ZE1 = new Int32Array(8), ZE2 = new Int32Array(8);
  var i0;
  for (i0 = 0; i0 < Z1.length; i0++) { Z1[i0] = rnd(); Z2[i0] = rnd(); }
  for (i0 = 0; i0 < 16; i0++) { ZC1[i0] = rnd(); ZC2[i0] = rnd(); }
  for (i0 = 0; i0 < 8; i0++) { ZE1[i0] = rnd(); ZE2[i0] = rnd(); }
  var ZS1 = rnd(), ZS2 = rnd();
  var H1 = 0, H2 = 0;
  function hash(pos) {
    var h1 = 0, h2 = 0, b = pos.b, v, idx;
    for (var i = 0; i < 64; i++) { v = b[i]; if (v) { idx = (v + 6) * 64 + i; h1 ^= Z1[idx]; h2 ^= Z2[idx]; } }
    if (pos.turn === -1) { h1 ^= ZS1; h2 ^= ZS2; }
    h1 ^= ZC1[pos.castle]; h2 ^= ZC2[pos.castle];
    if (pos.ep >= 0) { h1 ^= ZE1[pos.ep & 7]; h2 ^= ZE2[pos.ep & 7]; }
    H1 = h1; H2 = h2;
  }
  function hashOf(pos) { hash(pos); return H1; }

  var TTBITS = 19, TTSIZE = 1 << TTBITS, TTMASK = TTSIZE - 1;
  var tH2 = new Int32Array(TTSIZE), tD = new Int8Array(TTSIZE), tS = new Int32Array(TTSIZE), tF = new Int8Array(TTSIZE), tM = new Uint16Array(TTSIZE);
  function clear() { tH2.fill(0); tD.fill(-1); tM.fill(0); }
  clear();
  var INF = 1000000;

  var EGK = [-50,-40,-30,-20,-20,-30,-40,-50, -30,-20,-10,0,0,-10,-20,-30, -30,-10,20,30,30,20,-10,-30, -30,-10,30,40,40,30,-10,-30, -30,-10,30,40,40,30,-10,-30, -30,-10,20,30,30,20,-10,-30, -30,-30,0,0,0,0,-30,-30, -50,-30,-30,-30,-30,-30,-30,-50];
  var PASS = [0, 5, 10, 20, 38, 65, 110, 0];
  var wMinY = new Int8Array(8), wMaxY = new Int8Array(8), bMinY = new Int8Array(8), bMaxY = new Int8Array(8), wCnt = new Int8Array(8), bCnt = new Int8Array(8);

  function evaluate(pos) {
    var b = pos.b, mg = 0, eg = 0, i, v, a, x, y, np = 0, wk = -1, bk = -1, wb = 0, bb = 0, wMat = 0, bMat = 0;
    for (x = 0; x < 8; x++) { wMinY[x] = 9; bMinY[x] = 9; wMaxY[x] = -1; bMaxY[x] = -1; wCnt[x] = 0; bCnt[x] = 0; }
    for (i = 0; i < 64; i++) {
      v = b[i]; if (!v) continue;
      x = i & 7; y = i >> 3;
      if (v > 0) {
        a = v; var m = VAL[a];
        if (a === K) { wk = i; mg += PST[6][i]; eg += EGK[i]; }
        else {
          mg += m + PST[a][i]; eg += m + (a === P ? PST[1][i] + 8 : PST[a][i]);
          if (a === P) { wCnt[x]++; if (y < wMinY[x]) wMinY[x] = y; if (y > wMaxY[x]) wMaxY[x] = y; }
          else { np += m; wMat += m; if (a === B) wb++; }
        }
      } else {
        a = -v; var m2 = VAL[a], j = i ^ 56;
        if (a === K) { bk = i; mg -= PST[6][j]; eg -= EGK[j]; }
        else {
          mg -= m2 + PST[a][j]; eg -= m2 + (a === P ? PST[1][j] + 8 : PST[a][j]);
          if (a === P) { bCnt[x]++; if (y < bMinY[x]) bMinY[x] = y; if (y > bMaxY[x]) bMaxY[x] = y; }
          else { np += m2; bMat += m2; if (a === B) bb++; }
        }
      }
    }
    if (wb >= 2) { mg += 30; eg += 45; }
    if (bb >= 2) { mg -= 30; eg -= 45; }
    var f, lo, hi, ok;
    for (i = 0; i < 64; i++) {
      v = b[i]; a = v > 0 ? v : -v;
      if (a === P) {
        x = i & 7; y = i >> 3; lo = x > 0 ? x - 1 : 0; hi = x < 7 ? x + 1 : 7;
        if (v > 0) {
          ok = true;
          for (f = lo; f <= hi; f++) if (bMinY[f] < y) { ok = false; break; }
          if (ok) { mg += PASS[7 - y] >> 1; eg += PASS[7 - y] + ((7 - y) >= 4 ? 10 : 0); }
          if (wCnt[x] > 1) { mg -= 8; eg -= 14; }
          if ((x === 0 || wCnt[x - 1] === 0) && (x === 7 || wCnt[x + 1] === 0)) { mg -= 10; eg -= 14; }
        } else {
          ok = true;
          for (f = lo; f <= hi; f++) if (wMaxY[f] > y) { ok = false; break; }
          if (ok) { mg -= PASS[y] >> 1; eg -= PASS[y] + (y >= 4 ? 10 : 0); }
          if (bCnt[x] > 1) { mg += 8; eg += 14; }
          if ((x === 0 || bCnt[x - 1] === 0) && (x === 7 || bCnt[x + 1] === 0)) { mg += 10; eg += 14; }
        }
      } else if (a === R) {
        x = i & 7;
        if (v > 0) { if (wCnt[x] === 0) { mg += bCnt[x] === 0 ? 18 : 9; eg += 8; } }
        else { if (bCnt[x] === 0) { mg -= wCnt[x] === 0 ? 18 : 9; eg -= 8; } }
      }
    }
    /* безопасность короля: пешечный щит */
    if (np > 2600) {
      if (wk >= 0 && (wk >> 3) >= 6) {
        var wx = wk & 7, sh = 0;
        for (f = Math.max(0, wx - 1); f <= Math.min(7, wx + 1); f++) { var py = wMaxY[f]; if (py >= 5 && py <= 6) sh += py === 6 ? 12 : 8; else sh -= 10; }
        mg += sh;
      }
      if (bk >= 0 && (bk >> 3) <= 1) {
        var bx = bk & 7, sh2 = 0;
        for (f = Math.max(0, bx - 1); f <= Math.min(7, bx + 1); f++) { var py2 = bMinY[f]; if (py2 <= 2 && py2 >= 1) sh2 += py2 === 1 ? 12 : 8; else sh2 -= 10; }
        mg -= sh2;
      }
    }
    var ph = np * 256 / 6000; if (ph > 256) ph = 256;
    var s = (mg * ph + eg * (256 - ph)) / 256;
    /* добивание: загнать короля слабой стороны в угол */
    if (wk >= 0 && bk >= 0 && (wMat + bMat) < 1500) {
      var cd = function (sq) { var cx = sq & 7, cy = sq >> 3; return Math.abs(cx - 3.5) + Math.abs(cy - 3.5); };
      var kd = Math.abs((wk & 7) - (bk & 7)) + Math.abs((wk >> 3) - (bk >> 3));
      var wp = 0, bp = 0;
      for (x = 0; x < 8; x++) { wp += wCnt[x]; bp += bCnt[x]; }
      if (wMat > bMat + 200 && bp === 0) s += (14 - kd) * 6 + cd(bk) * 14;
      if (bMat > wMat + 200 && wp === 0) s -= (14 - kd) * 6 + cd(wk) * 14;
    }
    return ((pos.turn === 1 ? s : -s) | 0) + 8;
  }

  function mkey(m) { return m.f | (m.t << 6) | (m.p << 12); }

  function orderMoves(pos, ms, ttm, ply, c) {
    var b = pos.b, side = pos.turn === 1 ? 0 : 1, k1 = c.killers[ply * 2], k2 = c.killers[ply * 2 + 1];
    for (var i = 0; i < ms.length; i++) {
      var m = ms[i], cap = b[m.t], sc, key = mkey(m);
      if (ttm && key === ttm) sc = 10000000;
      else if (cap || m.fl === 1) {
        var victim = cap ? VAL[cap > 0 ? cap : -cap] : 100;
        sc = 1000000 + victim * 10 - VAL[Math.abs(b[m.f])] / 100 + (m.p ? VAL[m.p] : 0);
      } else if (m.p) sc = 900000 + VAL[m.p];
      else if (key === k1) sc = 800000;
      else if (key === k2) sc = 700000;
      else sc = c.hist[side * 4096 + m.f * 64 + m.t];
      m.s = sc;
    }
    ms.sort(function (a, d) { return d.s - a.s; });
  }

  function qs(pos, alpha, beta, ply, c) {
    if ((++c.nodes & 2047) === 0 && Date.now() > c.deadline) c.stop = true;
    if (c.stop) return 0;
    var stand = evaluate(pos);
    if (ply >= 8) return stand;
    if (stand >= beta) return stand;
    if (stand + 1000 < alpha) return alpha;
    if (stand > alpha) alpha = stand;
    var ms = pseudo(pos, true), t = pos.turn, b = pos.b, i;
    for (i = 0; i < ms.length; i++) {
      var m = ms[i], cap = b[m.t];
      m.s = (cap ? VAL[cap > 0 ? cap : -cap] * 10 : 1000) - VAL[Math.abs(b[m.f])] / 100 + (m.p ? VAL[m.p] : 0);
    }
    ms.sort(function (a, d) { return d.s - a.s; });
    var ksq = kingSq(b, t);
    for (i = 0; i < ms.length; i++) {
      var mv = ms[i];
      if (!mv.p && b[mv.t] && stand + VAL[Math.abs(b[mv.t])] + 200 < alpha && ply > 0) continue; /* делта-отсечение */
      var np = make(pos, mv), k = (mv.f === ksq) ? mv.t : ksq;
      if (attacked(np.b, k, -t)) continue;
      var sc = -qs(np, -beta, -alpha, ply + 1, c);
      if (c.stop) return 0;
      if (sc >= beta) return sc;
      if (sc > alpha) alpha = sc;
    }
    return alpha;
  }

  function hasPieces(pos, side) {
    var b = pos.b;
    for (var i = 0; i < 64; i++) { var v = b[i] * side; if (v >= 2 && v <= 5) return true; }
    return false;
  }

  function nm(pos, depth, alpha, beta, ply, c, allowNull) {
    if ((++c.nodes & 2047) === 0 && Date.now() > c.deadline) c.stop = true;
    if (c.stop) return 0;
    var t = pos.turn, b = pos.b, ksq = kingSq(b, t);
    if (ksq < 0) return -MATE + ply;
    var inchk = attacked(b, ksq, -t);
    if (inchk) depth++;
    if (ply >= 60) return evaluate(pos);
    if (pos.half >= 100) return 0;
    hash(pos);
    var h1 = H1, h2 = H2, i, j;
    for (j = c.plen - 2; j >= 0 && j >= c.plen - pos.half; j -= 2) if (c.path[j] === h1) return 0;
    if (depth <= 0) return qs(pos, alpha, beta, 0, c);
    var idx = h1 & TTMASK, ttm = 0;
    if (tH2[idx] === h2 && tD[idx] >= 0) {
      ttm = tM[idx];
      if (tD[idx] >= depth) {
        var ts = tS[idx];
        if (ts > MATE - 1000) ts -= ply; else if (ts < -MATE + 1000) ts += ply;
        var fl = tF[idx];
        if (fl === 0) return ts;
        if (fl === 1 && ts >= beta) return ts;
        if (fl === 2 && ts <= alpha) return ts;
      }
    }
    var pv = beta - alpha > 1;
    c.path[c.plen++] = h1;
    var result;
    /* нулевой ход */
    if (allowNull && !inchk && !pv && depth >= 3 && hasPieces(pos, t)) {
      var nul = { b: b, turn: -t, castle: pos.castle, ep: -1, half: pos.half + 1 };
      var ns = -nm(nul, depth - 3, -beta, -beta + 1, ply + 1, c, false);
      if (c.stop) { c.plen--; return 0; }
      if (ns >= beta) { c.plen--; return ns >= MATE - 1000 ? beta : ns; }
    }
    var ms = pseudo(pos, false);
    orderMoves(pos, ms, ttm, ply, c);
    var best = -INF, bestKey = 0, n = 0, origAlpha = alpha, side = t === 1 ? 0 : 1;
    for (i = 0; i < ms.length; i++) {
      var m = ms[i], np = make(pos, m), k = (m.f === ksq) ? m.t : ksq;
      if (attacked(np.b, k, -t)) continue;
      n++;
      var cap = b[m.t] !== 0 || m.fl === 1, sc;
      if (n === 1) sc = -nm(np, depth - 1, -beta, -alpha, ply + 1, c, true);
      else {
        var red = 0;
        if (depth >= 3 && n > 3 && !cap && !m.p && !inchk) red = (n > 8 && depth > 5) ? 2 : 1;
        sc = -nm(np, depth - 1 - red, -alpha - 1, -alpha, ply + 1, c, true);
        if (sc > alpha && red > 0) sc = -nm(np, depth - 1, -alpha - 1, -alpha, ply + 1, c, true);
        if (sc > alpha && sc < beta) sc = -nm(np, depth - 1, -beta, -alpha, ply + 1, c, true);
      }
      if (c.stop) { c.plen--; return 0; }
      if (sc > best) { best = sc; bestKey = mkey(m); }
      if (sc > alpha) {
        alpha = sc;
        if (alpha >= beta) {
          if (!cap && !m.p) {
            var kk = mkey(m);
            if (c.killers[ply * 2] !== kk) { c.killers[ply * 2 + 1] = c.killers[ply * 2]; c.killers[ply * 2] = kk; }
            c.hist[side * 4096 + m.f * 64 + m.t] += depth * depth;
          }
          break;
        }
      }
    }
    c.plen--;
    if (n === 0) return inchk ? -MATE + ply : 0;
    result = best;
    var flag = best <= origAlpha ? 2 : best >= beta ? 1 : 0;
    var st = best;
    if (st > MATE - 1000) st += ply; else if (st < -MATE + 1000) st -= ply;
    if (tD[idx] <= depth || tH2[idx] !== h2) { tH2[idx] = h2; tD[idx] = depth > 100 ? 100 : depth; tS[idx] = st; tF[idx] = flag; tM[idx] = bestKey; }
    return result;
  }

  function newCtx(ms, hist) {
    var path = (hist || []).slice();
    return { nodes: 0, stop: false, deadline: Date.now() + ms, killers: new Int32Array(256), hist: new Int32Array(8192), path: path, plen: path.length };
  }

  /* Главный поиск: возвращает {move, score (в сотых пешки, с точки зрения ходящего), depth, nodes} */
  function think(pos, o) {
    o = o || {};
    var ms = legal(pos);
    if (!ms.length) return null;
    var maxD = o.depth || 6, c = newCtx(o.ms || 1000, o.hist);
    hash(pos); c.path[c.plen++] = H1;
    var res = { move: ms[0], score: 0, depth: 0, nodes: 0 };
    if (ms.length === 1 && !o.full) { res.score = evaluate(pos); return res; }
    var t = pos.turn;
    orderMoves(pos, ms, 0, 0, c);
    for (var d = 1; d <= maxD; d++) {
      var alpha = -INF, beta = INF, bestI = -1, bestS = -INF, completed = true;
      for (var i = 0; i < ms.length; i++) {
        var np = make(pos, ms[i]), sc;
        if (i === 0) sc = -nm(np, d - 1, -beta, -alpha, 1, c, true);
        else {
          sc = -nm(np, d - 1, -alpha - 1, -alpha, 1, c, true);
          if (sc > alpha && !c.stop) sc = -nm(np, d - 1, -beta, -alpha, 1, c, true);
        }
        if (c.stop) { completed = false; break; }
        ms[i].s = sc;
        if (sc > bestS) { bestS = sc; bestI = i; }
        if (sc > alpha) alpha = sc;
      }
      if (bestI >= 0 && (completed || bestI === 0 ? true : true)) {
        if (completed || bestI > 0 || d === 1) {
          res = { move: ms[bestI], score: bestS, depth: completed ? d : d - 1, nodes: c.nodes };
          if (completed) {
            var bm = ms[bestI]; ms.splice(bestI, 1); ms.unshift(bm);
            /* остальные — по оценкам прошлой итерации */
            var rest = ms.slice(1).sort(function (a, e) { return (e.s || -INF) - (a.s || -INF); });
            ms = [bm].concat(rest);
          }
        }
      }
      if (!completed) break;
      if (bestS > MATE - 100 || bestS < -MATE + 100) { if (d >= 2) break; }
      if (Date.now() > c.deadline) break;
    }
    res.nodes = c.nodes;
    return res;
  }

  /* Оценка конкретного хода (с точки зрения того, кто его делает) */
  function evalMove(pos, move, depth, ms, hist) {
    var c = newCtx(ms || 800, hist);
    hash(pos); c.path[c.plen++] = H1;
    var np = make(pos, move), sc = 0, last = null;
    for (var d = 1; d <= depth; d++) {
      var s = -nm(np, d - 1, -INF, INF, 1, c, true);
      if (c.stop) break;
      last = s;
      if (Date.now() > c.deadline) break;
    }
    return last === null ? sc : last;
  }

  /* Уровни силы робота: 1..20 — слабые с ошибками, 21..30 — настоящий поиск */
  function levelCfg(L) {
    L = Math.max(1, Math.min(30, L));
    if (L > 20) return { strong: true, depth: 2 + (L - 20) , ms: [0, 120, 200, 320, 480, 700, 950, 1250, 1600, 2000, 2500][L - 20], noise: 0 };
    var table = [
      [1, 9999], [1, 700], [1, 520], [1, 400], [1, 300], [1, 220],
      [2, 420], [2, 330], [2, 260], [2, 200], [2, 150], [2, 110], [2, 80],
      [3, 280], [3, 220], [3, 170], [3, 130], [3, 95], [3, 70], [3, 45]
    ];
    var e = table[L - 1];
    return { depth: e[0], noise: e[1], q: L >= 14, ms: 1200 };
  }

  function bestMove(pos, level, hist) {
    var cfg = levelCfg(level);
    if (cfg.strong) {
      var r = think(pos, { depth: cfg.depth, ms: cfg.ms, hist: hist });
      return r ? r.move : null;
    }
    return weakMove(pos, level, cfg);
  }

  function toFEN(pos) {
    var L = ['', 'P', 'N', 'B', 'R', 'Q', 'K'], rows = [];
    for (var y = 0; y < 8; y++) {
      var s = '', e = 0;
      for (var x = 0; x < 8; x++) {
        var v = pos.b[y * 8 + x];
        if (!v) { e++; continue; }
        if (e) { s += e; e = 0; }
        s += v > 0 ? L[v] : L[-v].toLowerCase();
      }
      if (e) s += e;
      rows.push(s);
    }
    var c = (pos.castle & 1 ? 'K' : '') + (pos.castle & 2 ? 'Q' : '') + (pos.castle & 4 ? 'k' : '') + (pos.castle & 8 ? 'q' : '');
    return rows.join('/') + ' ' + (pos.turn === 1 ? 'w' : 'b') + ' ' + (c || '-') + ' - 0 1';
  }

  function perft(pos, d) {
    if (d === 0) return 1;
    var ms = legal(pos), n = 0;
    for (var i = 0; i < ms.length; i++) n += perft(make(pos, ms[i]), d - 1);
    return n;
  }

  return { fromFEN: fromFEN, start: start, legal: legal, make: make, status: status, inCheck: inCheck, key: key, insufficient: insufficient, bestMove: bestMove, kingSq: kingSq, perft: perft, toFEN: toFEN, levelCfg: levelCfg, think: think, evalMove: evalMove, evaluate: evaluate, hashOf: hashOf, clear: clear, MATE: MATE };
})();

/* ===== Бесконечные задачи «мат в один ход» ===== */
(function () {
  var E = Eng;
  var T = { P: 1, N: 2, B: 3, R: 4, Q: 5 };
  function ri(n) { return Math.floor(Math.random() * n); }
  function pick(a) { return a[ri(a.length)]; }
  function dist(a, b) { return Math.max(Math.abs((a & 7) - (b & 7)), Math.abs((a >> 3) - (b >> 3))); }
  function randSq(b, pawn) {
    for (var n = 0; n < 60; n++) { var s = ri(64); if (b[s]) continue; if (pawn && ((s >> 3) === 0 || (s >> 3) === 7)) continue; return s; }
    return -1;
  }
  function nearSq(b, c, pawn) {
    for (var n = 0; n < 40; n++) {
      var x = (c & 7) + ri(5) - 2, y = (c >> 3) + ri(5) - 2;
      if (x < 0 || x > 7 || y < 0 || y > 7) continue;
      var s = y * 8 + x; if (b[s]) continue; if (pawn && (y === 0 || y === 7)) continue; return s;
    }
    return randSq(b, pawn);
  }
  function edgeKing() {
    if (Math.random() < 0.8) {
      var e = ri(4), r = ri(8), q = [0, 7][ri(2)];
      if (Math.random() < 0.4) return pick([0, 7, 56, 63]);
      return e === 0 ? r : e === 1 ? 56 + r : e === 2 ? r * 8 : r * 8 + 7;
    }
    return ri(64);
  }
  var SAY = {
    R: 'Мат ладьёй: найди ход, после которого королю чёрных некуда деться.',
    Q: 'Мат ферзём: осторожно, не поставь пат! Королю должно быть некуда идти, но шах обязателен.',
    B: 'Мат слоном: слон бьёт по диагонали. Найди мат.',
    N: 'Мат конём: конь ходит буквой Г. Найди мат.',
    P: 'Мат пешкой: пешка бьёт по диагонали вперёд. Найди ход.',
    X: 'Найди мат. Подумай, какая фигура поставит его.'
  };
  function gen(kind) {
    kind = kind || 'X';
    for (var att = 0; att < 40000; att++) {
      var b = new Int8Array(64);
      var bk = edgeKing(); b[bk] = -6;
      var wk = -1;
      for (var q = 0; q < 30; q++) { var s = ri(64); if (!b[s] && dist(s, bk) >= 2) { wk = s; break; } }
      if (wk < 0) continue;
      b[wk] = 6;
      var main = kind === 'X' ? null : kind;
      var wl = [];
      if (kind === 'X') { var n = 2 + ri(3); for (var i = 0; i < n; i++) wl.push(pick(['R', 'R', 'Q', 'B', 'N', 'P'])); }
      else {
        wl.push(kind);
        var r0 = Math.random();
        if (kind === 'R' && r0 < 0.35) wl.push('R');
        if (kind === 'B' && r0 < 0.5) wl.push(pick(['B', 'N', 'P']));
        if (kind === 'N' && r0 < 0.5) wl.push(pick(['N', 'B', 'P']));
        if (kind === 'P') wl.push(pick(['P', 'R', 'B', 'N', 'Q']));
        if (kind === 'Q' && r0 < 0.3) wl.push(pick(['P', 'N']));
        if (Math.random() < 0.3) wl.push('P');
      }
      var ok = true;
      for (var j = 0; j < wl.length; j++) {
        var pw = wl[j] === 'P', sq = (kind === 'P' || kind === 'N' || kind === 'B') && Math.random() < 0.6 ? nearSq(b, bk, pw) : randSq(b, pw);
        if (sq < 0) { ok = false; break; }
        b[sq] = T[wl[j]];
      }
      if (!ok) continue;
      var nb = (kind === 'B' || kind === 'N' || kind === 'P') ? 2 + ri(5) : kind === 'X' ? 1 + ri(5) : ri(4);
      for (j = 0; j < nb; j++) {
        var t = pick(['P', 'P', 'P', 'N', 'B', 'R']), pb = t === 'P', s2 = Math.random() < 0.8 ? nearSq(b, bk, pb) : randSq(b, pb);
        if (s2 < 0) continue;
        b[s2] = -T[t];
      }
      var pos = { b: b, turn: 1, castle: 0, ep: -1, half: 0 };
      /* позиция должна быть законной: чёрный король не под шахом, белый тоже */
      var other = { b: b, turn: -1, castle: 0, ep: -1, half: 0 };
      if (E.inCheck(other) || E.inCheck(pos)) continue;
      var ms = E.legal(pos), mates = [], byMain = 0;
      for (j = 0; j < ms.length; j++) {
        if (E.status(E.make(pos, ms[j])) === 'mate') {
          mates.push(ms[j]);
          var pt = Math.abs(b[ms[j].f]);
          if (!main || pt === T[main]) byMain++;
        }
      }
      if (!mates.length || !byMain) continue;
      if (mates.length > (kind === 'X' ? 3 : 2)) continue;
      if (main && mates.some(function (m) { return Math.abs(b[m.f]) !== T[main]; }) && Math.random() < 0.7) continue;
      /* не слишком много пешек у чёрных рядом: просто и читаемо */
      return { fen: E.toFEN(pos), kind: kind, say: SAY[kind], mates: mates.length };
    }
    return null;
  }
  E.genPuzzle = gen;
})();

if (typeof module !== 'undefined') module.exports = Eng;
