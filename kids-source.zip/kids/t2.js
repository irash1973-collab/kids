var E=require('./engine.js');
function game(Lw,Lb){var p=E.start(),hist=[],keys={};E.clear();
 for(var ply=0;ply<300;ply++){var st=E.status(p);if(st==='mate')return p.turn===1?-1:1;if(st==='stalemate'||E.insufficient(p)||p.half>=100)return 0;
  var k=E.key(p);keys[k]=(keys[k]||0)+1;if(keys[k]>=3)return 0;
  hist.push(E.hashOf(p));var m=E.bestMove(p,p.turn===1?Lw:Lb,hist.slice(0,-1));p=E.make(p,m);}
 return 0;}
var a=+process.argv[2],b=+process.argv[3],n=+process.argv[4]||2,sc=0;
for(var i=0;i<n;i++){var r=game(a,b);sc+=r;var r2=game(b,a);sc-=r2;process.stdout.write(r+','+(-r2)+' ');}
console.log('\nL'+a+' vs L'+b+' score(for a):',sc,'of',2*n);
