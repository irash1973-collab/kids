const { chromium } = require('playwright');
(async()=>{
 const b=await chromium.launch(); const pg=await b.newPage({viewport:{width:420,height:900}}); const errs=[];
 pg.on('pageerror',e=>errs.push('PAGEERR '+e.message));
 await pg.goto('file:///home/claude/kids/index.html#puzzles'); await pg.waitForTimeout(500);
 await pg.click('#ansB, #ansBtn'); await pg.waitForTimeout(2000);
 console.log('puz', await pg.textContent('#msg'));
 await pg.goto('file:///home/claude/kids/index.html#board'); await pg.waitForTimeout(300);
 await pg.click('#bHint'); await pg.waitForTimeout(800);
 console.log('board', await pg.textContent('#msg'), await pg.textContent('h2'));
 await pg.goto('file:///home/claude/kids/index.html#play/3'); await pg.waitForTimeout(300);
 console.log('play ok', (await pg.$$('.lvbtn')).length);
 await pg.goto('file:///home/claude/kids/index.html#home'); await pg.waitForTimeout(300);
 console.log((await pg.textContent('.hero')).slice(0,200));
 console.log(errs.join('\n')); await b.close();
})();
