
  /* ---------- Дебютная книга: подсказки и робот играют нормальные дебюты ---------- */
  var OPEN = [
    ['Итальянская партия', 'e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 c2c3 g8f6 d2d3 d7d6 e1g1 e8g8'],
    ['Гамбит Эванса', 'e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 b2b4 c5b4 c2c3 b4a5 d2d4 e5d4 e1g1 d7d6'],
    ['Испанская партия', 'e2e4 e7e5 g1f3 b8c6 f1b5 a7a6 b5a4 g8f6 e1g1 f8e7 f1e1 b7b5 a4b3 d7d6 c2c3 e8g8'],
    ['Шотландская партия', 'e2e4 e7e5 g1f3 b8c6 d2d4 e5d4 f3d4 g8f6 b1c3 f8b4'],
    ['Защита Петрова', 'e2e4 e7e5 g1f3 g8f6 f3e5 d7d6 e5f3 f6e4 d2d4 d6d5 f1d3 f8e7 e1g1 b8c6'],
    ['Партия четырёх коней', 'e2e4 e7e5 g1f3 b8c6 b1c3 g8f6 f1b5 f8b4 e1g1 e8g8 d2d3 d7d6'],
    ['Защита Филидора', 'e2e4 e7e5 g1f3 d7d6 d2d4 g8f6 b1c3 b8d7 f1c4 f8e7 e1g1 e8g8'],
    ['Сицилианская защита', 'e2e4 c7c5 g1f3 b8c6 d2d4 c5d4 f3d4 g8f6 b1c3 d7d6'],
    ['Сицилианская, вариант Алапина', 'e2e4 c7c5 c2c3 g8f6 e4e5 f6d5 d2d4 c5d4 g1f3 b8c6 c3d4 d7d6'],
    ['Французская защита', 'e2e4 e7e6 d2d4 d7d5 b1c3 g8f6 c1g5 f8e7 e4e5 f6d7 g5e7 d8e7'],
    ['Французская, вариант Тарраша', 'e2e4 e7e6 d2d4 d7d5 b1d2 g8f6 e4e5 f6d7 f1d3 c7c5 c2c3 b8c6'],
    ['Защита Каро-Канн', 'e2e4 c7c6 d2d4 d7d5 b1c3 d5e4 c3e4 c8f5 e4g3 f5g6 h2h4 h7h6 g1f3 b8d7'],
    ['Скандинавская защита', 'e2e4 d7d5 e4d5 d8d5 b1c3 d5a5 d2d4 g8f6 g1f3 c7c6 f1c4 c8f5'],
    ['Защита Пирца', 'e2e4 d7d6 d2d4 g8f6 b1c3 g7g6 g1f3 f8g7 f1e2 e8g8 e1g1 c7c6'],
    ['Ферзевый гамбит, отказанный', 'd2d4 d7d5 c2c4 e7e6 b1c3 g8f6 c1g5 f8e7 e2e3 e8g8 g1f3 b8d7'],
    ['Ферзевый гамбит, принятый', 'd2d4 d7d5 c2c4 d5c4 g1f3 g8f6 e2e3 e7e6 f1c4 c7c5 e1g1 a7a6'],
    ['Славянская защита', 'd2d4 d7d5 c2c4 c7c6 g1f3 g8f6 b1c3 d5c4 a2a4 c8f5 e2e3 e7e6 f1c4 f8b4'],
    ['Староиндийская защита', 'd2d4 g8f6 c2c4 g7g6 b1c3 f8g7 e2e4 d7d6 g1f3 e8g8 f1e2 e7e5'],
    ['Защита Нимцовича', 'd2d4 g8f6 c2c4 e7e6 b1c3 f8b4 e2e3 e8g8 f1d3 d7d5 g1f3 c7c5 e1g1 b8c6'],
    ['Ферзевая индийская защита', 'd2d4 g8f6 c2c4 e7e6 g1f3 b7b6 g2g3 c8b7 f1g2 f8e7 e1g1 e8g8 b1c3 f6e4'],
    ['Лондонская система', 'd2d4 d7d5 g1f3 g8f6 c1f4 e7e6 e2e3 c7c5 c2c3 b8c6 b1d2 f8d6 f4g3 e8g8'],
    ['Система Колла', 'd2d4 d7d5 g1f3 g8f6 e2e3 e7e6 f1d3 c7c5 b2b3 b8c6 e1g1 f8d6 c1b2 e8g8'],
    ['Голландская защита', 'd2d4 f7f5 g2g3 g8f6 f1g2 e7e6 g1f3 f8e7 e1g1 e8g8 c2c4 d7d6'],
    ['Английское начало', 'c2c4 e7e5 b1c3 g8f6 g1f3 b8c6 g2g3 d7d5 c4d5 f6d5 f1g2 d5b6 e1g1 f8e7'],
    ['Дебют Рети', 'g1f3 d7d5 c2c4 e7e6 g2g3 g8f6 f1g2 f8e7 e1g1 e8g8 b2b3 c7c5']
  ];
  var BOOK = null, BOOKBAD = [];
  function sqIdx(s) { return (8 - +s[1]) * 8 + (s.charCodeAt(0) - 97); }
  function uciMove(pos, u) {
    var f = sqIdx(u.slice(0, 2)), t = sqIdx(u.slice(2, 4));
    var c = E.legal(pos).filter(function (m) { return m.f === f && m.t === t; });
    var pp = u.length > 4 ? { q: 5, r: 4, b: 3, n: 2 }[u[4]] : 0;
    if (pp) return c.filter(function (m) { return m.p === pp; })[0] || null;
    return c.filter(function (m) { return !m.p || m.p === 5; })[0] || null;
  }
  function buildBook() {
    BOOK = {}; BOOKBAD = [];
    OPEN.forEach(function (o) {
      var pos = E.start(), ok = true;
      o[1].split(' ').forEach(function (u) {
        if (!ok) return;
        var m = uciMove(pos, u);
        if (!m) { BOOKBAD.push(o[0] + ' ' + u); ok = false; return; }
        var k = E.key(pos), a = BOOK[k] || (BOOK[k] = []);
        if (!a.some(function (x) { return x.u === u; })) a.push({ m: m, u: u, name: o[0] });
        pos = E.make(pos, m);
      });
    });
  }
  function bookPick(pos) {
    if (!BOOK) buildBook();
    var a = BOOK[E.key(pos)];
    return a && a.length ? a[Math.floor(Math.random() * a.length)] : null;
  }
