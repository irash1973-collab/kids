
  /* ---------- Главная ---------- */
  function home() {
    var w = cnt(wins), mm = medalList(), got = mm.filter(function (m) { return m.ok; }).length;
    var pt = sumPz();
    var rk = rankOf(pts), nx = nextRank(pts);
    var title = w >= 100 ? 'Гроссмейстер' : w >= 40 ? 'Мастер' : w >= 10 ? 'Знаток' : w >= 1 ? 'Боец' : 'Новичок';
    var hh = '';
    Object.keys(HEROES).forEach(function (k) { hh += '<figure data-h="' + k + '">' + av(k) + '<span>' + esc(HEROES[k].n) + '</span></figure>'; });
    view.innerHTML =
      '<div class="hero"><span class="tag">Шахматная страна · UpGrade Chess Club</span><h1>Добро пожаловать в шахматную страну!</h1>' +
      '<p>Учись по урокам, решай задачи, играй с роботами и с друзьями, собирай награды. Всё бесплатно, прямо на телефоне или компьютере.</p>' +
      '<p class="note"><b>⭐ ' + pts + ' баллов · звание «' + rk + '»</b>' + (nx ? ' · до звания «' + nx[1] + '» ещё ' + (nx[0] - pts) : '') + '</p>' +
      '<div class="stage"><img src="' + IMG.yasmin + '" alt=""><img src="' + IMG.tima + '" alt=""><img src="' + IMG.simba + '" alt=""></div>' +
      '<span class="spark" style="top:14px;right:22px">⭐</span><span class="spark" style="top:60px;right:150px;animation-delay:-.7s">✨</span><span class="spark" style="top:110px;right:14px;animation-delay:-1.3s">♟</span></div>' +
      sayHero('king', 'За каждую победу тебя ждут звёзды и медали. Пройди все миры, и ты чемпион!', 'награды') +
      '<div class="cards">' +
      '<a class="card" href="#play"><img class="ch" src="' + IMG.arni + '" alt=""><span class="big">Игра с роботами</span><p>10 миров, 200 уровней. Начни с пешек и дойди до гроссмейстеров.</p><span class="pill">Побед: ' + w + ' из ' + TOTAL + ' · ' + title + '</span></a>' +
      '<a class="card" href="#puzzles"><img class="ch" src="' + IMG.fox + '" alt=""><span class="big">Задачи на мат</span><p>Мат ладьёй, ферзём, слоном, конём, пешкой. Задачи не кончаются.</p><span class="pill">Решено: ' + (pt + cnt(solved)) + '</span></a>' +
      '<a class="card" href="#awards"><img class="ch" src="' + IMG.king + '" alt=""><span class="big">Награды</span><p>Медали, кубки и звёзды за твои успехи.</p><span class="pill">Медалей: ' + got + ' из ' + mm.length + '</span></a>' +
      '<a class="card" href="#board"><img class="ch" src="' + IMG.tima + '" alt=""><span class="big">Играть вдвоём</span><p>Играй с другом на одном экране, расставляй позиции и разбирай партии: какие ходы были хорошие, а какие нет.</p><span class="pill">Друг против друга</span></a>' +
      '<a class="card" href="#lessons"><img class="ch" src="' + IMG.prof + '" alt=""><span class="big">Уроки</span><p>История шахмат, доска, ходы фигур со звёздочками и лабиринтами, шах, мат и ловушки.</p><span class="pill">' + lessonSummary() + '</span></a>' +
      '</div>' +
      '<section><h2>Наши герои</h2><div class="heroes" style="margin-top:12px">' + hh + '</div>' +
      '<p class="note" style="margin-top:10px">Герои из книги «Шахматная страна».</p></section>';
  }

  /* ---------- Награды ---------- */
  function awards() {
    var mm = medalList(), got = mm.filter(function (m) { return m.ok; }).length, h = '';
    var grp = '';
    mm.forEach(function (m) {
      if (m.grp !== grp) { if (grp) h += '</div></section>'; grp = m.grp; h += '<section class="mgroup"><h3>' + esc(grp) + '</h3><div class="mgrid">'; }
      h += '<div class="mcell' + (m.ok ? ' ok' : '') + '" title="' + esc(m.desc) + '">' + medalSvg(m, 52) + '<span>' + esc(m.name) + '</span><small>' + (m.ok ? 'получена' : esc(m.desc)) + '</small></div>';
    });
    h += '</div></section>';
    view.innerHTML = '<h2>Награды</h2>' +
      '<div class="stats"><div><b>' + pts + '</b><span>баллов · ' + rankOf(pts) + '</span></div><div><b>' + got + '</b><span>медалей из ' + mm.length + '</span></div><div><b>' + starsTotal() + '</b><span>звёзд за игры</span></div><div><b>' + cnt(wins) + '</b><span>побед над роботами</span></div><div><b>' + (sumPz() + cnt(solved)) + '</b><span>задач решено</span></div></div>' + h;
  }

  /* ---------- Задачи ---------- */
  var PKINDS = [['R', 'Ладья'], ['Q', 'Ферзь'], ['B', 'Слон'], ['N', 'Конь'], ['P', 'Пешка'], ['X', 'Разные фигуры'], ['C', 'Классика']];
  function puzzles() {
    var kind = lsGet('ukc_pk', 'R');
    var S = { pos: null, sel: null, targets: [], last: null, hint: null, flip: false };
    var cur = 0, busy = false, done = false, P = null, num = 0, usedHelp = false;
    var seg = '';
    PKINDS.forEach(function (k) { seg += '<button data-k="' + k[0] + '" aria-pressed="' + (k[0] === kind) + '">' + k[1] + '</button>'; });
    view.innerHTML =
      '<h2>Мат в один ход</h2><div class="seg" id="kinds" role="group" aria-label="Вид задач">' + seg + '</div><div id="who"></div>' + boardHTML() +
      '<div class="msg" id="msg" role="status" aria-live="polite"></div>' +
      '<div class="row"><button class="btn alt" id="hintBtn">Подсказка</button><button class="btn alt" id="ansBtn">Показать ответ</button><button class="btn" id="nextBtn" hidden>Дальше</button><span class="count" id="cnt"></span></div>' +
      '<div class="dots" id="dots" aria-label="Задачи"></div>';
    var msg = document.getElementById('msg');
    function setMsg(t, k) { msg.className = 'msg' + (k ? ' ' + k : ''); msg.textContent = t; }
    function counter() {
      var el = document.getElementById('cnt');
      el.textContent = kind === 'C' ? 'Решено: ' + cnt(solved) + ' из ' + PUZZLES.length : 'Решено: ' + pz[kind] + (kind === 'X' ? '' : ' · мат ' + PGEN[kind]);
    }
    function dots() {
      var d = document.getElementById('dots');
      if (kind !== 'C') { d.innerHTML = ''; return; }
      var h = '';
      PUZZLES.forEach(function (p, i) {
        h += '<button data-i="' + i + '" class="' + (i === cur ? 'cur ' : '') + (solved[i] ? 'done' : '') + '" aria-label="Задача ' + (i + 1) + (solved[i] ? ', решена' : '') + '">' + (i + 1) + '</button>';
      });
      d.innerHTML = h;
      d.onclick = function (e) { var b = e.target.closest('button'); if (b && !busy) load(+b.dataset.i); };
    }
    function load(i) {
      clearTimers(); busy = false; done = false; usedHelp = false;
      document.getElementById('ansBtn').disabled = false;
      if (kind === 'C') { cur = i; P = PUZZLES[i]; num = i + 1; }
      else { P = E.genPuzzle(kind); num = pz[kind] + 1; }
      S.pos = E.fromFEN(P.fen); S.sel = null; S.targets = []; S.last = null; S.hint = null;
      document.getElementById('who').innerHTML = sayHero(num % 2 ? 'simba' : 'arni', P.say, 'задача ' + num);
      setMsg('Ход белых. Поставь мат в один ход.');
      document.getElementById('nextBtn').hidden = true;
      counter(); draw(); dots();
    }
    function draw() { drawBoard(S, click); }
    function click(i) {
      if (busy || done) return;
      var v = S.pos.b[i];
      if (S.sel != null && S.targets.indexOf(i) >= 0) { move(S.sel, i); return; }
      if (v > 0) { S.sel = i; S.targets = movesFrom(S.pos, i).map(function (m) { return m.t; }); S.hint = null; }
      else { S.sel = null; S.targets = []; }
      draw();
    }
    function move(f, t) {
      var m = movesFrom(S.pos, f).filter(function (x) { return x.t === t; })[0];
      m = { f: m.f, t: m.t, p: m.p ? 5 : 0, fl: m.fl };
      var before = S.pos;
      S.pos = E.make(S.pos, m); S.sel = null; S.targets = []; S.hint = null; S.last = { f: f, t: t };
      var st = E.status(S.pos);
      if (st === 'mate') {
        var was = earnedIds();
        done = true;
        if (kind === 'C') { solved[cur] = true; lsSet('ukc_solved', solved); } else { pz[kind]++; lsSet('ukc_pz', pz); }
        counter();
        addPts(usedHelp ? 4 : 10, 'за задачу');
        var nm = newMedals(was);
        sfx('good'); confetti(nm.length ? 140 : 45);
        setMsg('Мат! Молодец!' + (nm.length ? ' Ты получил награду!' : ''), 'good');
        var nb = document.getElementById('nextBtn'); nb.hidden = false; nb.textContent = 'Дальше'; nb.focus();
        draw(); dots();
        if (nm.length) { later(function () { sfx('medal'); modal('<h2>Награда!</h2>' + medalsHTML(nm) + '<div class="row"><button class="btn" data-act="x">Ура!</button></div>'); }, 700); }
      } else {
        busy = true; sfx('bad');
        setMsg(st === 'stalemate' ? 'Это пат: королю некуда идти, но шаха нет. Нужен мат. Попробуй ещё!' : 'Это не мат. Король может ответить. Попробуй ещё!', 'bad');
        draw();
        later(function () { S.pos = before; S.last = null; busy = false; setMsg('Ход белых. Поставь мат в один ход.'); draw(); }, 1500);
      }
    }
    document.getElementById('hintBtn').onclick = function () {
      if (busy || done) return;
      var sol = E.legal(S.pos).filter(function (m) { return E.status(E.make(S.pos, m)) === 'mate'; });
      usedHelp = true;
      if (sol.length) { S.hint = sol[0].f; S.sel = null; S.targets = []; setMsg('Подсказка: ходить нужно фигурой, которая мигает (' + PNAME[Math.abs(S.pos.b[sol[0].f])] + ').'); draw(); }
    };
    document.getElementById('ansBtn').onclick = function () {
      if (busy || done) return;
      var sol = E.legal(S.pos).filter(function (m) { return E.status(E.make(S.pos, m)) === 'mate'; });
      if (!sol.length) return;
      var m = sol.filter(function (x) { return !x.p || x.p === 5; })[0] || sol[0];
      usedHelp = true; busy = true; S.sel = null; S.hint = m.f; S.targets = [m.t];
      setMsg('Смотри: ' + PNAME[Math.abs(S.pos.b[m.f])] + ' идёт на поле ' + SQN(m.t) + '.'); draw();
      later(function () {
        var pc = PNAME[Math.abs(S.pos.b[m.f])];
        S.pos = E.make(S.pos, { f: m.f, t: m.t, p: m.p ? 5 : 0, fl: m.fl }); S.hint = null; S.targets = []; S.last = { f: m.f, t: m.t };
        sfx('good'); done = true; busy = false;
        setMsg('Ответ: ' + pc + ' на ' + SQN(m.t) + ' — это мат! Эта задача без баллов. Дальше решай сама.', 'good');
        var nb = document.getElementById('nextBtn'); nb.hidden = false; nb.textContent = 'Дальше'; nb.focus();
        draw();
      }, 1300);
    };
    document.getElementById('nextBtn').onclick = function () {
      if (kind === 'C') { var n = cur + 1; for (var k = 0; k < PUZZLES.length; k++) { var j = (cur + 1 + k) % PUZZLES.length; if (!solved[j]) { n = j; break; } } load(n % PUZZLES.length); }
      else load(0);
    };
    document.getElementById('kinds').onclick = function (e) {
      var b = e.target.closest('button'); if (!b || busy) return;
      kind = b.dataset.k; lsSet('ukc_pk', kind);
      document.querySelectorAll('#kinds button').forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
      var first = 0; if (kind === 'C') for (var k = 0; k < PUZZLES.length; k++) if (!solved[k]) { first = k; break; }
      load(first);
    };
    var first0 = 0; if (kind === 'C') for (var k0 = 0; k0 < PUZZLES.length; k0++) if (!solved[k0]) { first0 = k0; break; }
    load(first0);
  }
