
  /* ---------- Разбор партии ---------- */
  var CLS = {
    brill: { n: 'Супер ход', s: '!!', c: 'cs' }, great: { n: 'Отличный ход', s: '!', c: 'cr' },
    best: { n: 'Лучший ход', s: '★', c: 'cb' }, good: { n: 'Хороший ход', s: '✓', c: 'cg' },
    inacc: { n: 'Сомнительный ход', s: '?!', c: 'ci' }, mistake: { n: 'Ошибка', s: '?', c: 'cm' }, blunder: { n: 'Грубая ошибка', s: '??', c: 'cz' }
  };
  var CLS_ORDER = ['brill', 'great', 'best', 'good', 'inacc', 'mistake', 'blunder'];
  function clampS(s) { return s > 900 ? 900 : s < -900 ? -900 : s; }
  function classify(same, loss) {
    if (same || loss <= 10) return 'best';
    if (loss < 50) return 'good';
    if (loss < 120) return 'inacc';
    if (loss < 260) return 'mistake';
    return 'blunder';
  }
  function classifySF(same, loss, gap, e0) {
    if (!same && loss > 10) return loss < 45 ? 'good' : loss < 110 ? 'inacc' : loss < 250 ? 'mistake' : 'blunder';
    if (e0 < 700 && e0 > -700) { if (gap >= 220) return 'brill'; if (gap >= 90) return 'great'; }
    return 'best';
  }
  function sameMove(a, b) { return a.f === b.f && a.t === b.t && (a.p || 0) === (b.p || 0); }
  function notation(m, before) {
    var after = E.make(before, m), cap = before.b[m.t] || m.fl === 1;
    var pc = Math.abs(before.b[m.f]);
    var t = m.fl === 2 ? (m.t > m.f ? 'O-O' : 'O-O-O') : (pc === 1 ? '' : PLET[pc] || (pc === 6 ? 'Кр' : '')) + SQN(m.f) + (cap ? '×' : '–') + SQN(m.t) + (m.p ? '=' + PLET[m.p] : '');
    var st = E.status(after);
    return t + (st === 'mate' ? '#' : st === 'check' ? '+' : '');
  }
  /* анализирует партию по шагам, не подвешивая страницу */
  function analyzeOld(recs, progress, done, token) {
    E.clear();
    var res = [], hh = [], i = 0;
    recs.forEach(function (r) { hh.push(E.hashOf(r.pos)); });
    function next() {
      if (token.cancel) return;
      if (i >= recs.length) { done(res); return; }
      var r = recs[i], pos = r.pos, hist = hh.slice(0, i);
      var best = E.think(pos, { depth: 7, ms: 300, hist: hist, full: true });
      var same = sameMove(best.move, r.m), s0 = best.score, s1 = s0;
      if (!same) s1 = E.evalMove(pos, r.m, Math.max(best.depth, 2), 300, hist);
      var loss = Math.max(0, clampS(s0) - clampS(s1));
      res.push({ cls: classify(same, loss), loss: loss, best: best.move, bestScore: s0, ev: s1 * pos.turn, text: notation(r.m, pos), turn: pos.turn });
      i++; progress(i, recs.length);
      setTimeout(next, 5);
    }
    next();
  }
  function analyzeAll(recs, progress, done, token) {
    progress(0, recs.length);
    SF.load().then(function (ok) {
      if (token.cancel) return;
      if (!ok) { analyzeOld(recs, progress, done, token); return; }
      var n = recs.length, ev = [], i = 0, poss = recs.map(function (r) { return r.pos; });
      poss.push(E.make(recs[n - 1].pos, recs[n - 1].m));
      function term(pos) { var st = E.status(pos); return st === 'mate' ? -30000 : (st === 'stalemate' ? 0 : null); }
      function step() {
        if (token.cancel) return;
        if (i > n) { finish(); return; }
        var pos = poss[i], t = term(pos);
        if (t !== null || E.insufficient(pos)) { ev[i] = { cp: t === null ? 0 : t, best: null, lines: [] }; i++; progress(Math.min(i, n), n); step(); return; }
        SF.eval(E.toFEN(pos), 11, 2).then(function (r) {
          if (token.cancel) return;
          if (!r || !r.lines.length) { analyzeOld(recs, progress, done, token); return; }
          ev[i] = { cp: r.lines[0].cp, mate: r.lines[0].mate, best: r.lines[0].move, lines: r.lines };
          i++; progress(Math.min(i, n), n); setTimeout(step, 0);
        });
      }
      function finish() {
        var res = [];
        recs.forEach(function (r, k) {
          var pos = r.pos, e0 = ev[k], e1 = ev[k + 1], bm = e0.best ? uciMove(pos, e0.best) : null;
          var same = bm ? sameMove(bm, r.m) : false, s0 = e0.cp, s1 = same ? s0 : -e1.cp;
          if (s0 > 600 && s1 > 600) s1 = Math.max(s1, s0 - 40);
          var loss = Math.max(0, clampS(s0) - clampS(s1));
          var gap = e0.lines.length > 1 ? clampS(e0.lines[0].cp) - clampS(e0.lines[1].cp) : 0;
          var best = bm || r.m;
          res.push({ cls: classifySF(same, loss, gap, s0), loss: loss, best: best, bestScore: s0, mate: e0.mate, ev: s1 * pos.turn, text: notation(r.m, pos), turn: pos.turn, same: same, sf: true });
        });
        done(res);
      }
      step();
    });
  }
  function profWords(a, r) {
    var bn = a.best && !a.same ? notation(a.best, r.pos) : '', mt = a.mate && a.mate > 0 && a.cls !== 'best' && a.cls !== 'brill' && a.cls !== 'great' ? ' Здесь можно было поставить мат!' : '';
    var P = {
      brill: ['Браво! Супер ход! Другие ходы были намного хуже, а ты нашёл единственный сильный.', 'Ура, супер ход! Так играют настоящие мастера.'],
      great: ['Отличный ход! Многие ходы здесь слабее, а ты выбрал самый сильный.', 'Молодец, отличный ход!'],
      best: ['Лучший ход! Компьютер выбрал бы такой же.', 'Верно, так и надо играть.'],
      good: ['Хороший ход. Есть ход чуть сильнее, но этот тоже годится.'],
      inacc: ['Сомнительный ход. Лучше было ' + bn + '.' + mt, 'Не самый удачный выбор: сильнее было ' + bn + '.' + mt],
      mistake: ['Ошибка. Перед ходом спроси себя: что теперь может сделать соперник? Лучше было ' + bn + '.' + mt],
      blunder: ['Грубая ошибка! Проверь, не осталась ли фигура без защиты. Лучше было ' + bn + '.' + mt, 'Ой, это зевок! Всегда смотри, куда может пойти фигура соперника. Нужно было ' + bn + '.' + mt]
    };
    var l = P[a.cls]; return l[(r.pos.turn + a.loss) % l.length < l.length ? Math.abs((a.loss | 0)) % l.length : 0];
  }
  function reviewHTML(res) {
    var cnt2 = { 1: {}, '-1': {} }, loss = { 1: 0, '-1': 0 }, num = { 1: 0, '-1': 0 };
    res.forEach(function (r) { cnt2[r.turn][r.cls] = (cnt2[r.turn][r.cls] || 0) + 1; loss[r.turn] += Math.min(r.loss, 400); num[r.turn]++; });
    function side(t, nm) {
      var acc = num[t] ? Math.round(100 * Math.exp(-(loss[t] / num[t]) / 120)) : 0, h = '<div class="rside"><b>' + nm + '</b><span class="acc">Точность ' + acc + '%</span><div class="chips">';
      CLS_ORDER.forEach(function (k) { if (!cnt2[t][k] && (k === 'brill' || k === 'great')) return; h += '<span class="chip ' + CLS[k].c + '"><i>' + CLS[k].s + '</i> ' + CLS[k].n + ': ' + (cnt2[t][k] || 0) + '</span>'; });
      return h + '</div></div>';
    }
    /* график оценки */
    var W = 300, H = 70, pts = [[0, H / 2]];
    res.forEach(function (r, k) { var v = Math.max(-600, Math.min(600, r.ev)); pts.push([(k + 1) * W / res.length, H / 2 - v / 600 * (H / 2 - 4)]); });
    var d = pts.map(function (p, k) { return (k ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1); }).join('');
    var area = d + 'L' + W + ' ' + H / 2 + 'L0 ' + H / 2 + 'Z';
    var graph = '<svg class="graph" viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none" role="img" aria-label="График оценки партии: выше середины лучше у белых"><rect width="' + W + '" height="' + H + '" fill="#2b2927"/><path d="' + area + '" fill="#f4f4f2" opacity=".9"/><line x1="0" x2="' + W + '" y1="' + H / 2 + '" y2="' + H / 2 + '" stroke="#ffc21a" stroke-width="1"/><path d="' + d + '" fill="none" stroke="#d7261e" stroke-width="2"/></svg>';
    return side(1, 'Белые') + side(-1, 'Чёрные') + '<div><small class="note">График: чем выше, тем лучше у белых.</small>' + graph + '</div>';
  }

  /* ---------- Доска: играть вдвоём и анализ ---------- */
  function boardPage() {
    var S = { pos: E.start(), sel: null, targets: [], last: null, hint: null, best: null, flip: false, coords: true };
    var past = [], future = [], recs = [], startPos = S.pos, mode = 'move', brush = null, keys = {}, over = false, busy = false, rv = null, token = { cancel: false };
    keys[E.key(S.pos)] = 1;
    view.innerHTML =
      '<h2>Играть вдвоём</h2>' + sayHero('prof', 'Здесь можно играть вдвоём с другом: белые и чёрные ходят по очереди на одном экране. Ещё можно расставлять позиции и разбирать партии. Я скажу, какие ходы хорошие, а какие нет.', 'друг против друга · анализ') +
      boardHTML() +
      '<div id="pal" class="pal" hidden></div>' +
      '<div id="promo" class="promo" hidden></div>' +
      '<div class="msg" id="msg" role="status" aria-live="polite"></div>' +
      '<div class="row" id="ctl">' +
      '<button class="btn alt" id="bNew">Новая партия</button><button class="btn alt" id="bUndo">Назад</button><button class="btn alt" id="bRedo">Вперёд</button>' +
      '<button class="btn alt" id="bFlip">Перевернуть</button><button class="btn alt" id="bHint">Лучший ход</button><button class="btn alt" id="bSetup">Расставить фигуры</button><button class="btn" id="bAn">Разобрать партию</button></div>' +
      '<div id="rvbox" hidden></div>' +
      '<div><h3>Ходы</h3><p class="mvlist" id="mv">Партия ещё не началась.</p></div>';
    var msg = document.getElementById('msg');
    function setMsg(t, kind) { msg.className = 'msg' + (kind ? ' ' + kind : ''); msg.textContent = t; }
    function who() { return S.pos.turn === 1 ? 'белых' : 'чёрных'; }
    function draw() { drawBoard(S, click); renderMoves(); document.getElementById('bUndo').disabled = !past.length || !!rv; document.getElementById('bRedo').disabled = !future.length || !!rv; document.getElementById('bAn').disabled = !recs.length; }
    function renderMoves() {
      var el = document.getElementById('mv');
      if (!recs.length) { el.textContent = 'Ходов пока нет.'; return; }
      var h = '', st0 = startPos.turn;
      recs.forEach(function (r, k) {
        var white = (st0 === 1) === (k % 2 === 0), num = Math.floor((k + (st0 === 1 ? 0 : 1)) / 2) + 1;
        var t = notation(r.m, r.pos), tag = '';
        if (rv && rv.res && rv.res[k]) { var c = CLS[rv.res[k].cls]; tag = '<span class="chip ' + c.c + (rv.idx === k ? ' sel' : '') + '" data-k="' + k + '" role="button" tabindex="0"><i>' + c.s + '</i> ' + esc(t) + '</span>'; } else tag = t;
        if (white) h += '<b>' + num + '.</b> ' + tag + ' ';
        else h += (k === 0 ? '<b>' + num + '…</b> ' : '') + tag + ' ';
      });
      el.innerHTML = h;
    }
    function turnMsg() {
      var st = E.status(S.pos);
      if (st === 'check') setMsg('Шах! Ход ' + who() + '.', 'bad'); else setMsg('Ход ' + who() + '.');
    }
    function checkEnd() {
      var st = E.status(S.pos);
      if (st === 'mate') { over = true; setMsg('Мат! Победили ' + (S.pos.turn === 1 ? 'чёрные' : 'белые') + '.', 'good'); return true; }
      if (st === 'stalemate') { over = true; setMsg('Пат: ходить некуда, но шаха нет. Ничья.'); return true; }
      if (E.insufficient(S.pos)) { over = true; setMsg('Ничья: слишком мало фигур для мата.'); return true; }
      if (S.pos.half >= 100) { over = true; setMsg('Ничья по правилу 50 ходов.'); return true; }
      if (keys[E.key(S.pos)] >= 3) { over = true; setMsg('Ничья: позиция повторилась три раза.'); return true; }
      over = false; return false;
    }
    function snapshot() { return { pos: S.pos, last: S.last, keys: JSON.parse(JSON.stringify(keys)), over: over }; }
    function restore(s) { S.pos = s.pos; S.last = s.last; keys = s.keys; over = s.over; S.sel = null; S.targets = []; S.hint = null; S.best = null; }
    function doMove(m) {
      past.push({ snap: snapshot() }); future = [];
      var before = S.pos;
      recs.push({ pos: before, m: m });
      S.pos = E.make(S.pos, m); S.last = { f: m.f, t: m.t }; S.sel = null; S.targets = []; S.hint = null; S.best = null;
      moveSound(before, m, S.pos);
      var k = E.key(S.pos); keys[k] = (keys[k] || 0) + 1;
      document.getElementById('promo').hidden = true; busy = false;
      if (!checkEnd()) turnMsg();
      draw();
    }
    function click(i) {
      if (busy || rv) return;
      if (mode === 'setup') { setupClick(i); return; }
      if (over) return;
      var v = S.pos.b[i];
      if (S.sel != null && S.targets.indexOf(i) >= 0) {
        var c = movesFrom(S.pos, S.sel).filter(function (x) { return x.t === i; });
        if (c.length > 1) { choosePromo(c); return; }
        doMove(c[0]); return;
      }
      if (v && (v > 0) === (S.pos.turn > 0)) { S.sel = i; S.targets = movesFrom(S.pos, i).map(function (m) { return m.t; }); S.hint = null; }
      else { S.sel = null; S.targets = []; }
      draw();
    }
    function choosePromo(c) {
      var el = document.getElementById('promo'), h = '<span>Во что превратить пешку?</span>';
      c.forEach(function (m, i) { h += '<button data-i="' + i + '" aria-label="' + PNAME[m.p] + '">' + pcHTML(S.pos.turn * m.p) + '</button>'; });
      el.innerHTML = h; el.hidden = false; busy = true;
      el.onclick = function (e) { var b = e.target.closest('button'); if (b) { busy = false; doMove(c[+b.dataset.i]); } };
    }
    function reset(pos, tn) {
      closeReview();
      S.pos = pos; S.sel = null; S.targets = []; S.last = null; S.hint = null; S.best = null; past = []; future = []; recs = []; startPos = pos; keys = {}; keys[E.key(pos)] = 1; over = false;
      document.getElementById('promo').hidden = true;
    }
    document.getElementById('bNew').onclick = function () { if (mode === 'setup') leaveSetup(true); reset(E.start(), 1); turnMsg(); draw(); };
    document.getElementById('bUndo').onclick = function () {
      if (!past.length || busy || rv) return;
      var p = past.pop(); future.push({ snap: snapshot(), rec: recs.pop() });
      restore(p.snap); if (!checkEnd()) turnMsg(); draw();
    };
    document.getElementById('bRedo').onclick = function () {
      if (!future.length || busy || rv) return;
      var f = future.pop(); past.push({ snap: snapshot() }); recs.push(f.rec);
      restore(f.snap); if (!checkEnd()) turnMsg(); draw();
    };
    document.getElementById('bFlip').onclick = function () { S.flip = !S.flip; draw(); };
    document.getElementById('bHint').onclick = function () {
      if (mode === 'setup' || over || busy || rv) return;
      setMsg('Думаю…'); busy = true;
      later(function () {
        var bk = bookPick(S.pos);
        if (bk) { busy = false; S.sel = null; S.hint = bk.m.f; S.targets = [bk.m.t]; setMsg('Дебютный ход: ' + notation(bk.m, S.pos) + ' (' + PNAME[Math.abs(S.pos.b[bk.m.f])] + '). Так играют в дебюте «' + bk.name + '».'); draw(); return; }
        var r = E.think(S.pos, { depth: 12, ms: 1500 }); busy = false;
        if (r) {
          var sc = r.score * S.pos.turn, txt = Math.abs(sc) > 90000 ? 'Есть мат!' : (sc > 40 ? 'У белых перевес: +' + (sc / 100).toFixed(1) : sc < -40 ? 'У чёрных перевес: +' + (-sc / 100).toFixed(1) : 'Позиция равная.');
          S.sel = null; S.hint = r.move.f; S.targets = [r.move.t]; setMsg('Лучший ход: ' + notation(r.move, S.pos) + ' (' + PNAME[Math.abs(S.pos.b[r.move.f])] + '). ' + txt);
        }
        draw();
      }, 60);
    };

    /* разбор */
    function closeReview() {
      token.cancel = true; token = { cancel: false }; rv = null;
      var bx = document.getElementById('rvbox'); bx.hidden = true; bx.innerHTML = '';
      document.getElementById('ctl').hidden = false; S.best = null;
    }
    function finalPos() { var r = recs[recs.length - 1]; return E.make(r.pos, r.m); }
    function startReview() {
      if (!recs.length || mode === 'setup') return;
      var bx = document.getElementById('rvbox'); bx.hidden = false;
      rv = { res: null, idx: -1 };
      var live = S.pos, liveLast = S.last;
      S.sel = null; S.targets = []; S.hint = null;
      bx.innerHTML = '<div class="rvhead"><h3>Разбор партии</h3><p id="prog" role="status">Профессор изучает партию…</p><div class="bar big" aria-hidden="true"><i id="pbar" style="width:0%"></i></div><button class="btn alt" id="rvStop">Отмена</button></div>';
      bx.querySelector('#rvStop').onclick = function () { S.pos = live; S.last = liveLast; closeReview(); turnMsg(); draw(); };
      document.getElementById('ctl').hidden = true;
      var tk = token;
      analyzeAll(recs, function (i, n) {
        var p = document.getElementById('prog'); if (p) p.textContent = 'Профессор изучает партию: ход ' + i + ' из ' + n;
        var b = document.getElementById('pbar'); if (b) b.style.width = (i * 100 / n) + '%';
      }, function (res) {
        if (tk.cancel) return;
        rv.res = res; rv.idx = res.length - 1; sfx('good');
        bx.innerHTML = '<div class="rvhead"><h3>Разбор партии</h3><div class="rvsum">' + reviewHTML(res) + '</div><div id="rvsay"></div>' +
          '<div class="row"><button class="btn alt" id="rvPrev">◀ Ход назад</button><button class="btn alt" id="rvNext">Ход вперёд ▶</button><button class="btn" id="rvClose">Закрыть разбор</button></div></div>';
        bx.querySelector('#rvPrev').onclick = function () { go(rv.idx - 1); };
        bx.querySelector('#rvNext').onclick = function () { go(rv.idx + 1); };
        bx.querySelector('#rvClose').onclick = function () { S.pos = live; S.last = liveLast; closeReview(); turnMsg(); draw(); };
        go(rv.idx);
      }, tk);
    }
    function go(k) {
      if (!rv || !rv.res) return;
      if (k < -1) k = -1; if (k > recs.length - 1) k = recs.length - 1;
      rv.idx = k;
      if (k < 0) { S.pos = startPos; S.last = null; S.best = null; S.badge = null; var sy0 = document.getElementById('rvsay'); if (sy0) sy0.innerHTML = ''; setMsg('Начало партии.'); draw(); return; }
      var r = recs[k], a = rv.res[k], c = CLS[a.cls], good = a.cls === 'best' || a.cls === 'good' || a.cls === 'brill' || a.cls === 'great';
      S.pos = k + 1 < recs.length ? recs[k + 1].pos : finalPos(); S.last = { f: r.m.f, t: r.m.t };
      S.best = good ? null : { f: a.best.f, t: a.best.t };
      S.badge = { sq: r.m.t, cls: a.cls, s: c.s };
      var side = r.pos.turn === 1 ? 'Белые' : 'Чёрные', bad = a.cls === 'blunder' || a.cls === 'mistake' || a.cls === 'inacc';
      setMsg(side + ': ' + a.text + c.s + ' — ' + c.n + '.', a.cls === 'blunder' || a.cls === 'mistake' ? 'bad' : (a.cls === 'inacc' ? '' : 'good'));
      var sy = document.getElementById('rvsay'); if (sy) sy.innerHTML = say(av('prof'), 'Профессор', profWords(a, r), c.s + ' ' + c.n);
      if (!rv.mute) sfx(a.cls === 'blunder' ? 'blunder' : a.cls === 'mistake' ? 'mistake' : a.cls === 'inacc' ? 'inacc' : a.cls === 'brill' ? 'brill' : a.cls === 'great' ? 'great' : 'move');
      draw();
    }
    document.getElementById('bAn').onclick = startReview;
    document.getElementById('mv').onclick = function (e) { var s = e.target.closest('[data-k]'); if (s && rv && rv.res) go(+s.dataset.k); };

    /* расстановка */
    function palette() {
      var el = document.getElementById('pal'), h = '';
      [1, 2, 3, 4, 5, 6].forEach(function (t) { h += '<button data-b="' + t + '" aria-label="белый ' + PNAME[t] + '">' + pcHTML(t) + '</button>'; });
      [1, 2, 3, 4, 5, 6].forEach(function (t) { h += '<button data-b="' + (-t) + '" aria-label="чёрный ' + PNAME[t] + '">' + pcHTML(-t) + '</button>'; });
      h += '<button data-b="0" class="erase">Убрать</button><button data-t="1" class="side">Ход белых</button><button data-t="-1" class="side">Ход чёрных</button><button id="clr" class="erase">Очистить доску</button>';
      el.innerHTML = h;
      el.onclick = function (e) {
        var b = e.target.closest('button'); if (!b) return;
        if (b.id === 'clr') { S.pos = { b: new Int8Array(64), turn: S.pos.turn, castle: 0, ep: -1, half: 0 }; draw(); return; }
        if (b.dataset.t) { S.pos = { b: S.pos.b, turn: +b.dataset.t, castle: 0, ep: -1, half: 0 }; mark(); setMsg('Расстановка: ходят ' + who() + '.'); return; }
        brush = +b.dataset.b; mark();
      };
      mark();
    }
    function mark() {
      document.querySelectorAll('#pal button[data-b]').forEach(function (b) { b.setAttribute('aria-pressed', String(brush !== null && +b.dataset.b === brush)); });
      document.querySelectorAll('#pal button[data-t]').forEach(function (b) { b.setAttribute('aria-pressed', String(+b.dataset.t === S.pos.turn)); });
    }
    function setupClick(i) {
      if (brush === null) { setMsg('Выбери фигуру внизу, потом нажимай на клетки.'); return; }
      var b = S.pos.b.slice(); b[i] = brush;
      S.pos = { b: b, turn: S.pos.turn, castle: 0, ep: -1, half: 0 }; draw();
    }
    function enterSetup() {
      if (rv) return;
      mode = 'setup'; brush = null; S.sel = null; S.targets = []; S.hint = null; S.last = null;
      document.getElementById('pal').hidden = false; palette();
      document.getElementById('bSetup').textContent = 'Готово, играть';
      setMsg('Расстановка: выбери фигуру и нажимай на клетки. Внизу можно выбрать, кто ходит.'); draw();
    }
    function leaveSetup(silent) {
      var b = S.pos.b, wk = 0, bk = 0, bad = false, i;
      for (i = 0; i < 64; i++) {
        if (b[i] === 6) wk++; if (b[i] === -6) bk++;
        if (Math.abs(b[i]) === 1 && (i < 8 || i >= 56)) bad = true;
      }
      if (!silent) {
        if (wk !== 1 || bk !== 1) { setMsg('Нужно ровно по одному королю каждого цвета.', 'bad'); return false; }
        if (bad) { setMsg('Пешки не могут стоять на первой и последней линиях.', 'bad'); return false; }
        var other = { b: b, turn: -S.pos.turn, castle: 0, ep: -1, half: 0 };
        if (E.inCheck(other)) { setMsg('Так нельзя: король стороны, которая не ходит, под шахом.', 'bad'); return false; }
      }
      var c = 0;
      if (b[60] === 6 && b[63] === 4) c |= 1; if (b[60] === 6 && b[56] === 4) c |= 2;
      if (b[4] === -6 && b[7] === -4) c |= 4; if (b[4] === -6 && b[0] === -4) c |= 8;
      mode = 'move'; document.getElementById('pal').hidden = true; document.getElementById('bSetup').textContent = 'Расставить фигуры';
      if (!silent) { reset({ b: b, turn: S.pos.turn, castle: c, ep: -1, half: 0 }, S.pos.turn); if (!checkEnd()) turnMsg(); draw(); }
      return true;
    }
    document.getElementById('bSetup').onclick = function () { if (mode === 'setup') leaveSetup(false); else enterSetup(); };

    if (pending) {
      /* партия из игры с роботом: загружаем и сразу разбираем */
      var pg = pending; pending = null;
      startPos = pg.start; recs = pg.recs; S.pos = pg.start; S.flip = !!pg.flip;
      past = [];
      S.last = null;
      draw(); startReview();
    } else { turnMsg(); draw(); }
  }

  function route() {
    clearTimers(); view.onclick = null;
    var parts = (location.hash || '#home').slice(1).split('/'), r = parts[0];
    if (['home', 'puzzles', 'play', 'lessons', 'lesson', 'board', 'awards'].indexOf(r) < 0) r = 'home';
    var m = document.getElementById('modal'); if (m) m.remove();
    setActive(r === 'lesson' ? 'lessons' : r);
    if (r === 'puzzles') puzzles();
    else if (r === 'play') { var w = +parts[1]; if (w >= 1 && w <= WORLDS.length && unlocked((w - 1) * SUB + 1)) playWorld(w - 1); else playWorlds(); }
    else if (r === 'lessons') lessons();
    else if (r === 'lesson') lessonPage(parts[1], +parts[2] || 0);
    else if (r === 'board') boardPage();
    else if (r === 'awards') awards();
    else home();
    window.scrollTo(0, 0);
  }
  window.addEventListener('hashchange', route);
  var sb = document.getElementById('snd');
  if (sb) {
    var upd = function () { sb.setAttribute('aria-pressed', String(!muted)); sb.textContent = muted ? 'Звук выкл' : 'Звук вкл'; };
    sb.onclick = function () { muted = !muted; lsSet('ukc_mute', muted); upd(); if (!muted) sfx('good'); };
    upd();
  }
  window.__T = { LESS: LESS, GROUPS: GROUPS, genPiece: genPiece, solveEx: solveEx, uciMove: uciMove, buildBook: buildBook, bad: function () { return BOOKBAD; }, E: E, mkRng: mkRng, lone: lone, PN: PN, SQN: SQN, notation: notation };
  updPts();
  route();
})();
