  /* ---------- Stockfish: сильный движок, грузится при первом использовании ---------- */
  var SF = (function () {
    var BASE = 'https://unpkg.com/stockfish@17.1.0/src/', JS = 'stockfish-17.1-lite-single-03e3232.js', WASM = 'stockfish-17.1-lite-single-03e3232.wasm';
    var w = null, state = 'idle', loadP = null, queue = [], cur = null, uciOk = false;
    function parse(line, job) {
      if (line.indexOf('info') === 0 && line.indexOf(' pv ') > 0) {
        var m = line.match(/multipv (\d+)/), k = m ? +m[1] : 1, sc = line.match(/score (cp|mate) (-?\d+)/), pv = line.match(/ pv (\S+)/), d = line.match(/depth (\d+)/);
        if (!sc || !pv) return;
        var v = +sc[2], cp = sc[1] === 'cp' ? v : (v > 0 ? 30000 - v * 10 : -30000 - v * 10);
        job.lines[k - 1] = { cp: cp, mate: sc[1] === 'mate' ? v : null, move: pv[1], depth: d ? +d[1] : 0 };
      }
    }
    function pump() {
      if (cur || !queue.length || state !== 'ready') return;
      cur = queue.shift();
      var j = cur; j.lines = [];
      w.postMessage('setoption name MultiPV value ' + (j.multipv || 1));
      if (j.elo) { w.postMessage('setoption name UCI_LimitStrength value true'); w.postMessage('setoption name UCI_Elo value ' + j.elo); }
      else w.postMessage('setoption name UCI_LimitStrength value false');
      w.postMessage('position fen ' + j.fen);
      w.postMessage('go ' + (j.depth ? 'depth ' + j.depth : '') + (j.ms ? ' movetime ' + j.ms : ''));
    }
    function onMsg(e) {
      var line = String(e.data);
      if (line === 'uciok') { uciOk = true; w.postMessage('isready'); return; }
      if (line === 'readyok' && state === 'loading') { state = 'ready'; if (loadP) loadP.res(true); pump(); return; }
      if (!cur) return;
      if (line.indexOf('bestmove') === 0) {
        var j = cur; cur = null;
        var bm = line.split(' ')[1];
        j.res({ best: bm, lines: j.lines.filter(Boolean) });
        pump();
      } else parse(line, cur);
    }
    function load() {
      if (state === 'ready') return Promise.resolve(true);
      if (state === 'fail') return Promise.resolve(false);
      if (loadP) return loadP.p;
      loadP = {};
      loadP.p = new Promise(function (res) {
        loadP.res = res; state = 'loading';
        var to = setTimeout(function () { if (state !== 'ready') { state = 'fail'; try { w && w.terminate(); } catch (e) {} res(false); } }, 40000);
        var origRes = res; loadP.res = function (v) { clearTimeout(to); origRes(v); };
        fetch(BASE + JS).then(function (r) { if (!r.ok) throw new Error('http'); return r.text(); }).then(function (txt) {
          var url = URL.createObjectURL(new Blob([txt], { type: 'text/javascript' })) + '#' + BASE + WASM;
          w = new Worker(url);
          w.onmessage = onMsg;
          w.onerror = function () { if (state !== 'ready') { state = 'fail'; loadP.res(false); } };
          w.postMessage('uci');
        }).catch(function () { state = 'fail'; loadP.res(false); });
      });
      return loadP.p;
    }
    function run(o) {
      return load().then(function (ok) {
        if (!ok) return null;
        return new Promise(function (res) { o.res = res; queue.push(o); pump(); });
      });
    }
    return {
      load: load,
      ok: function () { return state === 'ready'; },
      failed: function () { return state === 'fail'; },
      eval: function (fen, depth, multipv) { return run({ fen: fen, depth: depth || 12, multipv: multipv || 1 }); },
      move: function (fen, ms, elo) { return run({ fen: fen, ms: ms || 600, depth: 0, elo: elo || 0, multipv: 1 }); },
      clear: function () { queue.length = 0; }
    };
  })();
