  /* ---------- Живые герои: гуляют по низу экрана ---------- */
  (function () {
    var PH = {
      yasmin: ['Привет! Сыграем партию?', 'Пешки ходят вперёд, а бьют по диагонали!', 'Я люблю шахматы!'],
      tima: ['Я сегодня победил робота!', 'Хочешь решить задачку на мат?', 'Ура, ещё одна звезда!'],
      simba: ['Мяу! Не забывай про шах!', 'Конь ходит буквой Г. Мур!', 'Мур-мур, ты умница!'],
      arni: ['Гав! Ладья ходит по прямой!', 'Береги короля! Гав!', 'Давай играть!'],
      fox: ['Хи-хи, у меня есть хитрая ловушка!', 'Следи за ферзём!', 'Не зевай, я всё вижу!'],
      prof: ['Думай перед каждым ходом!', 'Рокировка: ход королём и ладьёй.', 'Шахматы учат думать.'],
      king: ['Ты молодец! Собирай звёзды!', 'Каждый ход — шаг к победе.', 'Добро пожаловать в мою страну!']
    };
    var still = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    var sky = document.createElement('div'); sky.id = 'sky';
    var sh = ['♙', '♘', '♗', '♖', '♕', '♔', '★', '♟'];
    for (var i = 0; i < 14; i++) {
      var s = document.createElement('span');
      s.textContent = sh[i % sh.length];
      s.style.left = (i * 7.3 + 2) % 100 + '%';
      s.style.fontSize = (22 + (i * 13) % 34) + 'px';
      s.style.animationDuration = (26 + (i * 5) % 22) + 's';
      s.style.animationDelay = -((i * 7) % 30) + 's';
      sky.appendChild(s);
    }
    document.body.insertBefore(sky, document.body.firstChild);
    var walk = document.createElement('div'); walk.id = 'walk';
    var bubs = document.createElement('div'); bubs.id = 'bubs';
    document.body.appendChild(walk); document.body.appendChild(bubs);
    var W = [], keys = Object.keys(HEROES), vw = window.innerWidth, last = 0, bt = 0;
    function size() { return vw < 560 ? 52 : 62; }
    keys.forEach(function (k, i) {
      var d = document.createElement('div'); d.className = 'wk'; d.setAttribute('role', 'button'); d.setAttribute('aria-label', HEROES[k].n);
      d.innerHTML = '<div class="fl"><img src="' + IMG[k] + '" alt="" width="62" height="62"></div>';
      walk.appendChild(d);
      var o = { k: k, el: d, x: (vw / keys.length) * i + 10, dir: i % 2 ? 1 : -1, sp: 22 + (i * 9) % 20, rest: 0, n: 0 };
      d.addEventListener('click', function () { talk(o); });
      W.push(o);
    });
    function talk(o) {
      var l = PH[o.k], t = l[o.n++ % l.length];
      o.rest = 3.5; o.el.classList.add('rest', 'jump');
      setTimeout(function () { o.el.classList.remove('jump'); }, 650);
      bubs.innerHTML = '';
      var b = document.createElement('div'); b.className = 'bub'; b.innerHTML = '<b>' + esc(HEROES[o.k].n) + ':</b> ' + esc(t);
      bubs.appendChild(b);
      var sz = size(), cx = o.x + sz / 2, bw = Math.min(190, vw - 16);
      var left = Math.max(8, Math.min(vw - bw - 8, cx - bw / 2));
      b.style.left = left + 'px'; b.style.setProperty('--tx', (cx - left) + 'px');
      clearTimeout(bt); bt = setTimeout(function () { bubs.innerHTML = ''; }, 3200);
      try { sfx('good'); } catch (e) {}
    }
    function place(o) {
      o.el.firstChild.style.transform = o.dir > 0 ? 'scaleX(1)' : 'scaleX(-1)';
      o.el.style.transform = 'translateX(' + o.x + 'px)';
    }
    function tick(ts) {
      var dt = Math.min(.05, (ts - last) / 1000 || 0); last = ts;
      var sz = size(), max = vw - sz - 4;
      W.forEach(function (o) {
        if (o.rest > 0) { o.rest -= dt; if (o.rest <= 0) o.el.classList.remove('rest'); }
        else {
          o.x += o.dir * o.sp * dt;
          if (o.x < 4) { o.x = 4; o.dir = 1; } if (o.x > max) { o.x = max; o.dir = -1; }
          if (Math.random() < dt * .25) { o.rest = 1 + Math.random() * 2.5; o.el.classList.add('rest'); if (Math.random() < .5) o.dir = -o.dir; }
        }
        place(o);
      });
      requestAnimationFrame(tick);
    }
    window.addEventListener('resize', function () { vw = window.innerWidth; });
    W.forEach(function (o) { place(o); });
    if (still) W.forEach(function (o) { o.el.classList.add('rest'); }); else requestAnimationFrame(tick);
    function sync() { var h = location.hash || '#home'; walk.classList.toggle('dim', h === '#board' || h.indexOf('#play/') === 0 || h.indexOf('#game') === 0); }
    window.addEventListener('hashchange', sync); sync();
  })();
  /* ---------- «Показать решение» только после 3 неверных попыток ---------- */
  (function () {
    var cur = null, tries = 0, lim = 3, mo = null;
    function btn() { return document.getElementById('ansB') || document.getElementById('ansBtn'); }
    function paint(b) {
      if (!b) return;
      var open = tries >= lim, tx = open ? 'Показать решение' : 'Решение откроется после ' + (lim - tries) + ' ' + (lim - tries === 1 ? 'ошибки' : 'ошибок');
      if (b.disabled !== !open) b.disabled = !open;
      if (b.textContent !== tx) b.textContent = tx;
    }
    function scan() {
      var b = btn();
      if (b !== cur) { cur = b; tries = 0; }
      if (b) paint(b);
    }
    var seen = '';
    new MutationObserver(function (ms) {
      var b = btn(); if (!b) { cur = null; return; }
      ms.forEach(function (m) {
        var t = m.target; var el = t.nodeType === 3 ? t.parentNode : t;
        if (el && el.classList && el.classList.contains('msg') && el.classList.contains('bad') && m.type === 'childList' && m.addedNodes.length) tries++;
      });
      scan();
    }).observe(view, { childList: true, subtree: true, characterData: true });
  })();
