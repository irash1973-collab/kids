(function () {
  var HEROES = {
    yasmin: { n: 'Ясмин' }, tima: { n: 'Тима' }, simba: { n: 'Кот Симба' }, arni: { n: 'Арни' },
    fox: { n: 'Хитринка' }, prof: { n: 'Профессор' }, king: { n: 'Король Добромир' }
  };
  function pcHTML(v) { var t = Math.abs(v); return '<svg class="pcs ' + (v > 0 ? 'w' : 'b') + '" viewBox="0 0 45 45" aria-hidden="true"><use href="#pc' + t + '"/></svg>'; }
  var boardTheme = 'bw';
  var PNAME = { 1: 'пешка', 2: 'конь', 3: 'слон', 4: 'ладья', 5: 'ферзь', 6: 'король' };
  var PGEN = { R: 'ладьёй', Q: 'ферзём', B: 'слоном', N: 'конём', P: 'пешкой', X: 'разными фигурами' };
  var PICON = { R: 4, Q: 5, B: 3, N: 2, P: 1, X: 6 };

/*CLASSIC*/

  var ROBOTS = ['Малыш Болтик', 'Винтик', 'Шурупчик', 'Гайка', 'Кнопка', 'Искорка', 'Шестерёнка', 'Лампочка', 'Моторчик', 'Турбо',
    'Магнит', 'Радар', 'Пиксель', 'Квант', 'Титан', 'Орбита', 'Вектор', 'Матрица', 'Нейрон', 'Квазар',
    'Сигма', 'Комета', 'Гроссробот', 'Мега-Мозг', 'Король роботов'];
  /* 10 миров по 20 уровней */
  var SUB = 20;
  var WORLDS = [
    { n: 'Мир Пешек', g: 'arni', pc: 1, fen: '4k3/pppppppp/8/8/8/8/PPPPPPPP/4K3 w - - 0 1', t: 'Здесь воюют пешки. Доведи пешку до края доски, и она станет ферзём!' },
    { n: 'Мир Коней', g: 'simba', pc: 2, fen: '1n2k1n1/pppppppp/8/8/8/8/PPPPPPPP/1N2K1N1 w - - 0 1', t: 'Кони прыгают через фигуры. Следи за вилками!' },
    { n: 'Мир Слонов', g: 'prof', pc: 3, fen: '2b1kb2/pppppppp/8/8/8/8/PPPPPPPP/2B1KB2 w - - 0 1', t: 'Слоны ходят по диагоналям и стреляют издалека.' },
    { n: 'Мир Ферзей', g: 'tima', pc: 5, fen: '3qk3/pppppppp/8/8/8/8/PPPPPPPP/3QK3 w - - 0 1', t: 'Ферзь самая сильная фигура. Береги его!' },
    { n: 'Мир Королей', g: 'king', pc: 6, fen: '4k3/2pppp2/8/8/8/8/2PPPP2/4K3 w - - 0 1', t: 'Короли и пешки. Король помогает пешкам дойти до цели.' },
    { n: 'Мир Ладей', g: 'fox', pc: 4, fen: 'r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R w - - 0 1', t: 'Ладьи любят открытые линии. Заставь их работать!' },
    { n: 'Мир Лёгких фигур', g: 'arni', pc: 2, fen: 'rnb1kbnr/pppppppp/8/8/8/8/PPPPPPPP/RNB1KBNR w KQkq - 0 1', t: 'Играем без ферзей: кони, слоны и ладьи.' },
    { n: 'Мир Большой армии', g: 'simba', pc: 5, fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', t: 'Настоящая партия со всеми фигурами.' },
    { n: 'Мир Мастеров', g: 'prof', pc: 3, fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', t: 'Сильные роботы. Тактика и расчёт решают всё.' },
    { n: 'Мир Гроссмейстеров', g: 'king', pc: 6, fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', t: 'Самые сильные роботы. Победишь всех, станешь чемпионом!' }
  ];
  var TOTAL = WORLDS.length * SUB;
  function robotName(n) { return ROBOTS[(n - 1) % ROBOTS.length]; }
  function robotLevel(n) { return 1 + Math.round((n - 1) * 29 / (TOTAL - 1)); }
  var LESSONS = ['Шахматная доска', 'История шахмат', 'Ладья', 'Слон', 'Ферзь', 'Конь', 'Король', 'Пешка', 'Шах и мат'];

  var E = Eng;
  var view = document.getElementById('view');
  var timers = [];
  function later(fn, ms) { var t = setTimeout(fn, ms); timers.push(t); return t; }
  function clearTimers() { timers.forEach(clearTimeout); timers = []; }

  function lsGet(k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  var solved = lsGet('ukc_solved', {});          /* классические задачи */
  var pz = lsGet('ukc_pz', { R: 0, Q: 0, B: 0, N: 0, P: 0, X: 0 }); /* решено бесконечных задач по видам */
  var wins = lsGet('ukc_w2', {});                /* номер уровня (1..200) -> звёзды 1..3 */
  var openAll = lsGet('ukc_all', false);
  var muted = lsGet('ukc_mute', false);
  boardTheme = lsGet('ukc_board', 'bw');
  var pts = lsGet('ukc_pts', 0);                 /* баллы */
  var les = lsGet('ukc_les', {});                /* уроки: id -> {done:n, best:n} */
  function cnt(o) { return Object.keys(o).length; }
  var RANKS = [[0, 'Новичок'], [100, 'Ученик'], [300, 'Знаток'], [700, 'Игрок'], [1500, 'Мастер'], [3000, 'Гроссмейстер'], [6000, 'Чемпион']];
  function rankOf(p) { var r = RANKS[0]; RANKS.forEach(function (x) { if (p >= x[0]) r = x; }); return r[1]; }
  function nextRank(p) { for (var i = 0; i < RANKS.length; i++) if (RANKS[i][0] > p) return RANKS[i]; return null; }
  function updPts() { var e = document.getElementById('pts'); if (e) e.textContent = '⭐ ' + pts; }
  function toast(t) {
    var d = document.createElement('div'); d.className = 'toast'; d.setAttribute('role', 'status'); d.textContent = t; document.body.appendChild(d);
    setTimeout(function () { d.classList.add('out'); }, 1700); setTimeout(function () { d.remove(); }, 2300);
  }
  function addPts(n, why) {
    if (n <= 0) return;
    var before = rankOf(pts); pts += n; lsSet('ukc_pts', pts); updPts();
    toast('+' + n + ' ' + (why || 'баллов'));
    var after = rankOf(pts);
    if (after !== before) setTimeout(function () { sfx('medal'); confetti(80); toast('Новое звание: ' + after + '!'); }, 900);
  }
  function sumPz() { var s = 0; for (var k in pz) s += pz[k]; return s; }
  function starsTotal() { var s = 0; for (var k in wins) s += wins[k]; return s; }

  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function av(k) { return '<img class="av" src="' + IMG[k] + '" alt="" width="64" height="64">'; }
  function robotSvg(L, size) {
    var h = (L * 37) % 360, mouth = 8 + (L % 5) * 2, ears = L > 10;
    return '<svg class="av" width="' + (size || 64) + '" height="' + (size || 64) + '" viewBox="0 0 64 64" aria-hidden="true">' +
      '<circle cx="32" cy="32" r="31" fill="hsl(' + h + ' 85% 88%)"/>' +
      '<line x1="32" y1="9" x2="32" y2="18" stroke="#1b1a19" stroke-width="2"/><circle cx="32" cy="8" r="3.4" fill="hsl(' + h + ' 85% 45%)"/>' +
      (ears ? '<rect x="9" y="27" width="6" height="12" rx="3" fill="hsl(' + h + ' 60% 45%)"/><rect x="49" y="27" width="6" height="12" rx="3" fill="hsl(' + h + ' 60% 45%)"/>' : '') +
      '<rect x="14" y="18" width="36" height="31" rx="10" fill="hsl(' + h + ' 70% 62%)" stroke="#1b1a19" stroke-width="2"/>' +
      '<circle cx="25" cy="32" r="5" fill="#fff"/><circle cx="39" cy="32" r="5" fill="#fff"/>' +
      '<circle cx="26" cy="33" r="2.2" fill="#1b1a19"/><circle cx="40" cy="33" r="2.2" fill="#1b1a19"/>' +
      '<rect x="' + (32 - mouth / 2) + '" y="41" width="' + mouth + '" height="3" rx="1.5" fill="#1b1a19"/></svg>';
  }
  function say(avatar, name, text, sub) {
    return '<div class="say">' + avatar + '<div><p>' + esc(text) + '</p><small>' + esc(name) + (sub ? ' · ' + esc(sub) : '') + '</small></div></div>';
  }
  function sayHero(k, text, sub) { return say(av(k), HEROES[k].n, text, sub); }
  function starSvg(on) {
    return '<svg class="star' + (on ? ' on' : '') + '" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.8l2.8 5.9 6.4.8-4.7 4.5 1.2 6.4L12 17.2 6.3 20.4l1.2-6.4L2.8 9.5l6.4-.8z"/></svg>';
  }
  function setActive(r) {
    document.querySelectorAll('.nav a').forEach(function (a) {
      if (a.dataset.r === r) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
  }

  /* ---------- Звуки (WebAudio, без файлов) ---------- */
  var AC = null;
  function ac() {
    if (muted) return null;
    if (!AC) { try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { AC = null; } }
    if (AC && AC.state === 'suspended') { try { AC.resume(); } catch (e) {} }
    return AC;
  }
  function tone(f, at, dur, type, vol) {
    var c = ac(); if (!c) return;
    var o = c.createOscillator(), g = c.createGain(), t0 = c.currentTime + at;
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol || 0.15, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(c.destination); o.start(t0); o.stop(t0 + dur + 0.05);
  }
  var Snd = {
    move: function () { tone(540, 0, 0.07, 'triangle', 0.13); },
    cap: function () { tone(200, 0, 0.1, 'square', 0.1); tone(130, 0.05, 0.14, 'square', 0.09); },
    check: function () { tone(880, 0, 0.09, 'sine', 0.14); tone(1175, 0.08, 0.14, 'sine', 0.14); },
    bad: function () { tone(220, 0, 0.2, 'sawtooth', 0.09); tone(165, 0.15, 0.3, 'sawtooth', 0.09); },
    good: function () { [523, 659, 784].forEach(function (f, i) { tone(f, i * 0.09, 0.2, 'triangle', 0.17); }); },
    win: function () { [523, 659, 784, 1047].forEach(function (f, i) { tone(f, i * 0.11, 0.25, 'triangle', 0.18); }); tone(1047, 0.5, 0.6, 'sine', 0.14); tone(784, 0.5, 0.6, 'sine', 0.1); tone(659, 0.5, 0.6, 'sine', 0.1); },
    world: function () { [392, 523, 659, 784, 1047, 1319].forEach(function (f, i) { tone(f, i * 0.13, 0.3, 'triangle', 0.18); }); [523, 659, 784, 1047].forEach(function (f) { tone(f, 0.85, 0.9, 'sine', 0.1); }); },
    blunder: function () { tone(300, 0, 0.15, 'sawtooth', 0.12); tone(220, 0.14, 0.18, 'sawtooth', 0.12); tone(140, 0.3, 0.45, 'sawtooth', 0.12); },
    mistake: function () { tone(280, 0, 0.18, 'square', 0.09); tone(210, 0.16, 0.3, 'square', 0.09); },
    inacc: function () { tone(440, 0, 0.12, 'triangle', 0.12); tone(392, 0.1, 0.22, 'triangle', 0.12); },
    great: function () { tone(660, 0, 0.12, 'triangle', 0.16); tone(880, 0.1, 0.28, 'triangle', 0.16); },
    brill: function () { [523, 659, 784, 1047, 1319].forEach(function (f, i) { tone(f, i * 0.07, 0.25, 'triangle', 0.17); }); tone(1568, 0.4, 0.6, 'sine', 0.12); },
    medal: function () { [1319, 1568, 1976, 2349].forEach(function (f, i) { tone(f, i * 0.07, 0.25, 'sine', 0.1); }); }
  };
  function sfx(n) { try { if (!muted && Snd[n]) Snd[n](); } catch (e) {} }
  function moveSound(before, m, after) {
    var cap = before.b[m.t] || m.fl === 1, st = E.status(after);
    sfx(st === 'mate' ? 'check' : st === 'check' ? 'check' : cap ? 'cap' : 'move');
  }

  /* ---------- Конфетти ---------- */
  var fx = document.getElementById('fx'), fxRun = false, parts = [];
  function confetti(n) {
    if (!fx) return;
    var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) n = Math.round(n / 5);
    var w = fx.width = innerWidth, h = fx.height = innerHeight;
    var cols = ['#d7261e', '#ffc21a', '#ffffff', '#1f8a4c', '#2f7de1', '#ff7ab6'];
    for (var i = 0; i < n; i++) {
      parts.push({ x: w / 2 + (Math.random() - 0.5) * w * 0.5, y: h * 0.35, vx: (Math.random() - 0.5) * 12, vy: -Math.random() * 13 - 3, s: 6 + Math.random() * 7, r: Math.random() * 6, vr: (Math.random() - 0.5) * 0.4, c: cols[i % cols.length], life: 0 });
    }
    if (fxRun) return; fxRun = true;
    var ctx = fx.getContext('2d');
    (function step() {
      ctx.clearRect(0, 0, fx.width, fx.height);
      parts = parts.filter(function (p) { return p.y < fx.height + 20 && p.life < 260; });
      parts.forEach(function (p) {
        p.vy += 0.3; p.vx *= 0.99; p.x += p.vx; p.y += p.vy; p.r += p.vr; p.life++;
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.fillStyle = p.c; ctx.globalAlpha = Math.max(0, 1 - p.life / 260);
        ctx.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2); ctx.restore();
      });
      if (parts.length) requestAnimationFrame(step); else { fxRun = false; ctx.clearRect(0, 0, fx.width, fx.height); }
    })();
  }

  /* ---------- Награды ---------- */
  var TIERS = [
    { k: 5, n: 'Бронза', c: '#cd7f32' }, { k: 10, n: 'Серебро', c: '#aab4bd' }, { k: 15, n: 'Золото', c: '#ffc21a' }, { k: 20, n: 'Кубок чемпиона', c: '#e8452c' }
  ];
  function worldWins(w) { var c = 0; for (var j = 1; j <= SUB; j++) if (wins[w * SUB + j]) c++; return c; }
  function medalList() {
    var L = [], w, i;
    for (w = 0; w < WORLDS.length; w++) {
      var ww = worldWins(w);
      for (i = 0; i < TIERS.length; i++) L.push({ id: 'w' + w + 't' + i, grp: WORLDS[w].n, name: TIERS[i].n, desc: TIERS[i].k + ' побед в мире «' + WORLDS[w].n.replace('Мир ', '') + '»', ok: ww >= TIERS[i].k, c: TIERS[i].c, pc: WORLDS[w].pc, tier: i });
    }
    [[1, 'Первая победа'], [10, 'Десять побед'], [50, 'Пятьдесят побед'], [100, 'Сто побед'], [200, 'Все роботы побеждены']].forEach(function (x, ix) {
      L.push({ id: 'g' + x[0], grp: 'Игра', name: x[1], desc: x[0] + ' ' + (x[0] === 1 ? 'победа' : 'побед') + ' над роботами', ok: cnt(wins) >= x[0], c: ['#cd7f32', '#aab4bd', '#ffc21a', '#e8452c', '#8a2be2'][ix], pc: 6, tier: Math.min(ix, 3) });
    });
    var kinds = ['R', 'Q', 'B', 'N', 'P', 'X'];
    kinds.forEach(function (k) {
      [[10, 0, 'Бронза'], [50, 1, 'Серебро'], [100, 2, 'Золото']].forEach(function (t) {
        L.push({ id: 'p' + k + t[0], grp: 'Задачи', name: t[2] + ': мат ' + PGEN[k], desc: t[0] + ' задач решено (мат ' + PGEN[k] + ')', ok: pz[k] >= t[0], c: TIERS[t[1]].c, pc: PICON[k], tier: t[1] });
      });
    });
    return L;
  }
  function earnedIds() { var o = {}; medalList().forEach(function (m) { if (m.ok) o[m.id] = m; }); return o; }
  function medalSvg(m, size) {
    var s = size || 56, c = m.ok ? m.c : '#cfc9c3';
    return '<svg class="medal' + (m.ok ? '' : ' off') + '" width="' + s + '" height="' + s + '" viewBox="0 0 56 56" aria-hidden="true">' +
      '<path d="M16 2h9l5 14h-9z" fill="#d7261e"/><path d="M40 2h-9l-5 14h9z" fill="#ffc21a"/>' +
      '<circle cx="28" cy="34" r="19" fill="' + c + '" stroke="#1b1a19" stroke-width="2"/><circle cx="28" cy="34" r="14" fill="none" stroke="rgba(255,255,255,.65)" stroke-width="2"/>' +
      '<g transform="translate(14 20) scale(.62)"><use href="#pc' + m.pc + '" class="mpc"/></g></svg>';
  }
  /* показывает новые награды; вызывать с набором «до» */
  function newMedals(before) {
    var now = earnedIds(), out = [];
    for (var id in now) if (!before[id]) out.push(now[id]);
    return out;
  }
  function medalsHTML(list) {
    if (!list.length) return '';
    var h = '<div class="newm"><b>Новые награды!</b><div class="mrow">';
    list.forEach(function (m) { h += '<div class="mitem">' + medalSvg(m, 64) + '<span>' + esc(m.name) + '</span><small>' + esc(m.grp) + '</small></div>'; });
    return h + '</div></div>';
  }

  /* окно с наградой */
  function modal(html, onClose) {
    var old = document.getElementById('modal'); if (old) old.remove();
    var d = document.createElement('div'); d.id = 'modal'; d.className = 'modal'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-modal', 'true');
    d.innerHTML = '<div class="mbox">' + html + '</div>';
    document.body.appendChild(d);
    var prev = document.activeElement;
    function close() { d.remove(); if (prev && prev.focus) try { prev.focus(); } catch (e) {} if (onClose) onClose(); }
    d.addEventListener('click', function (e) {
      var b = e.target.closest('[data-act]');
      if (b) { var a = b.dataset.act; close(); if (modal.acts && modal.acts[a]) modal.acts[a](); }
      else if (e.target === d) close();
    });
    var f = d.querySelector('button'); if (f) f.focus();
    return close;
  }
  modal.acts = {};

  function boardHTML() {
    return '<div class="seg boardtheme" id="bt" role="group" aria-label="Цвет доски"><button data-t="bw">Классическая</button><button data-t="green">Зелёная</button><button data-t="brown">Коричневая</button></div>' +
      '<div class="boardbox"><div class="board" id="board" role="grid" aria-label="Шахматная доска"></div></div>';
  }
  function applyTheme() {
    var el = document.getElementById('board'); if (el) el.dataset.board = boardTheme;
    document.querySelectorAll('#bt button').forEach(function (b) { b.setAttribute('aria-pressed', String(b.dataset.t === boardTheme)); });
  }
  function drawBoard(S, onClick) {
    var el = document.getElementById('board');
    if (!el) return;
    var bt = document.getElementById('bt');
    if (bt && !bt.onclick) bt.onclick = function (e) { var b = e.target.closest('button'); if (!b) return; boardTheme = b.dataset.t; lsSet('ukc_board', boardTheme); applyTheme(); };
    applyTheme();
    var checkSq = E.inCheck(S.pos) ? E.kingSq(S.pos.b, S.pos.turn) : -1;
    var html = '';
    for (var k = 0; k < 64; k++) {
      var i = S.flip ? 63 - k : k, x = i % 8, y = (i / 8) | 0, v = S.pos.b[i];
      var cls = 'sq' + ((x + y) % 2 === 0 ? ' l' : '');
      if (S.sel === i) cls += ' sel';
      if (S.hint === i) cls += ' hint';
      if (S.last && (S.last.f === i || S.last.t === i)) cls += ' last';
      if (S.best && (S.best.f === i || S.best.t === i)) cls += ' bestm';
      var bdg = S.badge && S.badge.sq === i ? S.badge : null; if (bdg) cls += ' bg-' + bdg.cls;
      if (S.targets && S.targets.indexOf(i) >= 0) cls += ' tg' + (v ? ' cap' : '');
      if (checkSq === i) cls += ' chk';
      var mk = S.mark && S.mark[i], co = '';
      if (S.hl && S.hl[i]) cls += ' hl';
      if (mk === 'wall') cls += ' wall';
      if (true) {
        if (x === (S.flip ? 7 : 0)) co += '<i class="co r">' + (8 - y) + '</i>';
        if (y === (S.flip ? 0 : 7)) co += '<i class="co f">' + 'abcdefgh'[x] + '</i>';
      }
      var label = (v ? (v > 0 ? 'белый ' : 'чёрный ') + PNAME[Math.abs(v)] : mk === 'wall' ? 'стена' : mk === 'star' ? 'звезда' : mk === 'flag' ? 'флажок' : 'пустое поле') + ', ' + SQN(i);
      html += '<button class="' + cls + '" data-i="' + i + '" aria-label="' + label + '">' +
        (v ? pcHTML(v) : '') + (bdg ? '<span class="bdg b-' + bdg.cls + '">' + bdg.s + '</span>' : '') + (mk === 'star' ? '<span class="mk">★</span>' : mk === 'flag' ? '<span class="mk fl">⚑</span>' : '') + co + '</button>';
    }
    el.innerHTML = html;
    el.onclick = function (e) { var b = e.target.closest('.sq'); if (b) onClick(+b.dataset.i); };
  }
  function movesFrom(pos, i) { return E.legal(pos).filter(function (m) { return m.f === i; }); }
  var SQN = function (i) { return 'abcdefgh'[i % 8] + (8 - (i >> 3)); };
  var PLET = { 2: 'К', 3: 'С', 4: 'Л', 5: 'Ф' };
  function matDiff(pos, side) {
    var V = [0, 1, 3, 3, 5, 9, 0], s = 0;
    for (var i = 0; i < 64; i++) { var v = pos.b[i]; if (v) s += (v > 0 ? 1 : -1) * V[Math.abs(v)] * side; }
    return s;
  }
