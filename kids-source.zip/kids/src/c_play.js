
  /* ---------- Игра с роботами: 10 миров по 20 уровней ---------- */
  var pending = null; /* партия, переданная на разбор */
  function unlocked(n) { return openAll || n === 1 || !!wins[n - 1] || !!wins[n]; }
  function starsRow(n, s) { var h = ''; for (var i = 1; i <= 3; i++) h += starSvg(i <= n); return '<span class="srow" aria-label="' + n + ' из 3 звёзд">' + h + '</span>'; }

  function playWorlds() {
    var h = '<h2>Игра с роботами</h2><p class="note">10 миров, в каждом 20 уровней. Обыграй робота, и откроется следующий уровень. Играем по настоящим правилам.</p><div class="wgrid">';
    WORLDS.forEach(function (w, wi) {
      var ok = unlocked(wi * SUB + 1), c = worldWins(wi);
      h += '<a class="wcard' + (ok ? '' : ' locked') + (c === SUB ? ' full' : '') + '" href="' + (ok ? '#play/' + (wi + 1) : '#play') + '"' + (ok ? '' : ' aria-disabled="true"') + '>' +
        '<span class="wpc">' + pcHTML(w.pc) + '</span><span class="wn">' + (wi + 1) + '. ' + esc(w.n) + '</span>' +
        '<span class="bar" aria-hidden="true"><i style="width:' + (c * 100 / SUB) + '%"></i></span><span class="wc">' + (ok ? c + ' из ' + SUB : 'закрыт') + '</span></a>';
    });
    h += '</div><div class="row"><button class="btn alt" id="openAll" aria-pressed="' + openAll + '">' + (openAll ? 'Закрыть уровни снова' : 'Открыть все уровни') + '</button></div>';
    view.innerHTML = h;
    view.onclick = function (e) {
      if (e.target.id === 'openAll') { openAll = !openAll; lsSet('ukc_all', openAll); playWorlds(); }
    };
  }

  function playWorld(wi) {
    var w = WORLDS[wi];
    var h = '<div class="row"><a class="btn alt" href="#play">Все миры</a></div>' +
      '<section class="world"><div class="wh">' + av(w.g) + '<div><h2>' + (wi + 1) + '. ' + esc(w.n) + '</h2><p>' + esc(w.t) + '</p></div></div>' +
      '<p class="note">Побед в мире: ' + worldWins(wi) + ' из ' + SUB + '</p><div class="lvgrid">';
    for (var j = 1; j <= SUB; j++) {
      var n = wi * SUB + j, ok = unlocked(n), s = wins[n] || 0;
      h += '<button class="lvbtn' + (s ? ' won' : '') + '" data-l="' + n + '"' + (ok ? '' : ' disabled') + ' aria-label="Уровень ' + j + ', ' + robotName(n) + (ok ? '' : ', закрыт') + (s ? ', пройден на ' + s + ' из 3 звёзд' : '') + '">' +
        robotSvg(n, 44) + '<span class="ln">' + j + '</span><span class="rn">' + esc(robotName(n)) + '</span>' + (s ? starsRow(s) : (ok ? '' : '<span class="lock">закрыт</span>')) + '</button>';
    }
    h += '</div></section>';
    view.innerHTML = h;
    view.onclick = function (e) {
      var b = e.target.closest('.lvbtn');
      if (b && !b.disabled) playGame(+b.dataset.l);
    };
  }

  function playGame(n) {
    view.onclick = null;
    var G, you = 1, hints = 3;
    var wi = Math.floor((n - 1) / SUB), sub = n - wi * SUB, world = WORLDS[wi];
    var L = robotLevel(n), name = robotName(n);
    view.innerHTML =
      '<div class="row"><button class="btn alt" id="back">К уровням</button></div>' +
      '<h2>' + esc(world.n) + ' · уровень ' + sub + '</h2><div id="who"></div>' +
      '<div class="seg" id="side" role="group" aria-label="Цвет фигур"><button data-c="1" aria-pressed="true">Играю белыми</button><button data-c="-1" aria-pressed="false">Играю чёрными</button></div>' +
      boardHTML() +
      '<div id="promo" class="promo" hidden></div>' +
      '<div class="msg" id="msg" role="status" aria-live="polite"></div>' +
      '<div class="row"><button class="btn" id="newBtn">Новая игра</button><button class="btn alt" id="hintBtn">Подсказка</button><button class="btn alt" id="anBtn" hidden>Разобрать партию</button><button class="btn" id="nextLv" hidden>Следующий уровень</button></div>';
    var msg = document.getElementById('msg');
    function setMsg(t, kind) { msg.className = 'msg' + (kind ? ' ' + kind : ''); msg.textContent = t; }
    var intro = L <= 6 ? 'Привет! Я ' + name + ', я только учусь. Сыграем?' : L <= 18 ? 'Привет! Я ' + name + '. Сыграем партию?' : L <= 24 ? 'Я ' + name + '. Играю серьёзно, не зевай!' : 'Я ' + name + '. Это сильный соперник. Удачи!';
    document.getElementById('who').innerHTML = say(robotSvg(n, 64), name, intro, 'уровень ' + n + ' из ' + TOTAL);

    function newGame() {
      if (L >= 22) SF.load();
      clearTimers(); E.clear(); hints = 3;
      var p0 = E.fromFEN(world.fen);
      G = { start: p0, pos: p0, keys: {}, hh: [], rec: [], sel: null, targets: [], last: null, hint: null, over: false, busy: false, flip: you === -1 };
      G.keys[E.key(G.pos)] = 1; G.hh.push(E.hashOf(G.pos)); window.__G = G;
      document.getElementById('promo').hidden = true;
      document.getElementById('nextLv').hidden = true; document.getElementById('anBtn').hidden = true;
      document.getElementById('hintBtn').disabled = false; document.getElementById('hintBtn').textContent = 'Подсказка (' + hints + ')';
      document.querySelectorAll('#side button').forEach(function (b) { b.setAttribute('aria-pressed', String(+b.dataset.c === you)); });
      setMsg(you === 1 ? 'Твой ход. Ты играешь белыми.' : 'Робот ходит первым. Ты играешь чёрными.');
      draw();
      if (you === -1) robotTurn();
    }
    function draw() { drawBoard(G, click); }
    function afterGame() {
      document.getElementById('anBtn').hidden = !G.rec.length;
      document.getElementById('hintBtn').disabled = true;
    }
    function win() {
      var was = earnedIds(), diff = matDiff(G.pos, you), stars = diff >= 2 ? 3 : diff >= 0 ? 2 : 1;
      var firstTime = !wins[n];
      wins[n] = Math.max(wins[n] || 0, stars); lsSet('ukc_w2', wins);
      var nm = newMedals(was), worldDone = (worldWins(wi) === SUB) && firstTime;
      addPts(firstTime ? 20 + stars * 10 + (worldDone ? 200 : 0) : stars * 3, firstTime ? 'за победу' : 'за повтор');
      afterGame();
      if (n < TOTAL) document.getElementById('nextLv').hidden = false;
      setMsg(n === TOTAL ? 'Ты обыграл всех роботов! Ты чемпион шахматной страны!' : 'Мат! Ты победил ' + name + '!', 'good');
      sfx(worldDone || n === TOTAL ? 'world' : 'win'); confetti(worldDone || n === TOTAL ? 320 : 130);
      later(function () {
        var h = '<h2>' + (n === TOTAL ? 'Ты чемпион!' : worldDone ? 'Мир пройден!' : 'Победа!') + '</h2>' +
          '<div class="bigstars" aria-label="' + stars + ' из 3 звёзд">' + [1, 2, 3].map(function (i) { return '<span style="animation-delay:' + (i * 0.25) + 's">' + starSvg(i <= stars) + '</span>'; }).join('') + '</div>' +
          '<p>' + (worldDone ? 'Ты прошёл все 20 уровней: «' + esc(world.n) + '». Получай кубок!' : 'Ты обыграл робота ' + esc(name) + '.') + '</p>' +
          (stars < 3 ? '<p class="note">Три звезды даёт победа с запасом фигур. Попробуй сыграть ещё!</p>' : '') +
          medalsHTML(nm) +
          '<div class="row">' + (n < TOTAL ? '<button class="btn" data-act="next">Следующий уровень</button>' : '') + '<button class="btn alt" data-act="an">Разобрать партию</button><button class="btn alt" data-act="back">К уровням</button></div>';
        if (nm.length) sfx('medal');
        modal.acts = {
          next: function () { playGame(n + 1); },
          an: function () { openAnalysis(); },
          back: function () { location.hash = '#play/' + (wi + 1); }
        };
        modal(h);
      }, 900);
    }
    function openAnalysis() { pending = { start: G.start, recs: G.rec.slice(), flip: you === -1 }; location.hash = '#board'; }
    function finish(text, kind, won) {
      G.over = true; setMsg(text, kind);
      if (won) win(); else { sfx(kind === 'bad' ? 'bad' : 'move'); afterGame(); }
    }
    function checkEnd() {
      var st = E.status(G.pos);
      if (st === 'mate') {
        var humanWon = (-G.pos.turn) === you;
        if (humanWon) finish('Мат! Ты победил!', 'good', true);
        else finish('Мат. Робот победил. Разбери партию и сыграй ещё раз!', 'bad', false);
        return true;
      }
      if (st === 'stalemate') { finish('Пат: ходить некуда, но шаха нет. Это ничья. Сыграй ещё!', '', false); return true; }
      if (E.insufficient(G.pos)) { finish('Ничья: у обоих слишком мало фигур для мата.', '', false); return true; }
      if (G.pos.half >= 100) { finish('Ничья по правилу 50 ходов.', '', false); return true; }
      if (G.keys[E.key(G.pos)] >= 3) { finish('Ничья: одна и та же позиция повторилась три раза.', '', false); return true; }
      return false;
    }
    function apply(m) {
      var before = G.pos;
      G.rec.push({ pos: before, m: m });
      G.pos = E.make(G.pos, m); G.last = { f: m.f, t: m.t }; G.sel = null; G.targets = []; G.hint = null;
      var k = E.key(G.pos); G.keys[k] = (G.keys[k] || 0) + 1; G.hh.push(E.hashOf(G.pos));
      moveSound(before, m, G.pos);
    }
    function robotTurn() {
      G.busy = true; draw();
      setMsg('Робот думает…');
      later(function () {
        var bk = L >= 8 && Math.random() < 0.9 ? bookPick(G.pos) : null;
        var g0 = G;
        function fin(r) {
          if (G !== g0 || G.over) return;
          if (r) apply(r);
          G.busy = false;
          draw();
          if (checkEnd()) { draw(); return; }
          setMsg(E.inCheck(G.pos) ? 'Тебе шах! Защити короля.' : 'Твой ход.', E.inCheck(G.pos) ? 'bad' : '');
        }
        if (bk || L < 22 || SF.failed()) { fin(bk ? bk.m : E.bestMove(G.pos, L, G.hh.slice(0, -1))); return; }
        var elo = Math.round(1500 + (L - 22) * 1300 / 8), pos0 = G.pos;
        SF.move(E.toFEN(pos0), 500, elo).then(function (r) {
          var m = r && r.best ? uciMove(pos0, r.best) : null;
          fin(m || E.bestMove(pos0, L, g0.hh.slice(0, -1)));
        });
      }, 120);
    }
    function humanMove(f, t) {
      var cands = movesFrom(G.pos, f).filter(function (x) { return x.t === t; });
      if (cands.length > 1) { choosePromo(cands); return; }
      doHuman(cands[0]);
    }
    function doHuman(m) {
      document.getElementById('promo').hidden = true;
      apply(m); draw();
      if (checkEnd()) { draw(); return; }
      if (E.inCheck(G.pos)) setMsg('Шах!');
      robotTurn();
    }
    function choosePromo(cands) {
      var el = document.getElementById('promo'), h = '<span>Во что превратить пешку?</span>';
      cands.forEach(function (c, i) { h += '<button data-i="' + i + '" aria-label="' + PNAME[c.p] + '">' + pcHTML(you * c.p) + '</button>'; });
      el.innerHTML = h; el.hidden = false;
      G.busy = true;
      el.onclick = function (e) {
        var b = e.target.closest('button'); if (!b) return;
        G.busy = false; doHuman(cands[+b.dataset.i]);
      };
    }
    function click(i) {
      if (G.busy || G.over) return;
      var v = G.pos.b[i];
      if (G.sel != null && G.targets.indexOf(i) >= 0) { humanMove(G.sel, i); return; }
      if (v && (v > 0) === (you > 0)) { G.sel = i; G.targets = movesFrom(G.pos, i).map(function (m) { return m.t; }); G.hint = null; }
      else { G.sel = null; G.targets = []; }
      draw();
    }
    document.getElementById('hintBtn').onclick = function () {
      if (G.busy || G.over || hints <= 0) { if (hints <= 0) setMsg('Подсказки закончились. Думай сам, ты справишься!'); return; }
      hints--; this.textContent = 'Подсказка (' + hints + ')';
      G.busy = true; setMsg('Думаю над подсказкой…');
      later(function () {
        var bk = bookPick(G.pos);
        if (bk) { G.busy = false; G.sel = null; G.hint = bk.m.f; G.targets = [bk.m.t]; setMsg('Дебютный ход: ' + notation(bk.m, G.pos) + '. Так играют в дебюте «' + bk.name + '». Ходи ' + PNAME[Math.abs(G.pos.b[bk.m.f])] + ' с мигающего поля на отмеченное.'); draw(); return; }
        var r = E.think(G.pos, { depth: 8, ms: 700, hist: G.hh.slice(0, -1) });
        G.busy = false;
        if (r) { G.sel = null; G.hint = r.move.f; G.targets = [r.move.t]; setMsg('Подсказка: попробуй сходить ' + PNAME[Math.abs(G.pos.b[r.move.f])] + ' с мигающего поля на отмеченное.'); }
        draw();
      }, 60);
    };
    document.getElementById('back').onclick = function () { clearTimers(); location.hash = '#play/' + (wi + 1); };
    document.getElementById('newBtn').onclick = newGame;
    document.getElementById('anBtn').onclick = openAnalysis;
    document.getElementById('nextLv').onclick = function () { playGame(n + 1); };
    document.getElementById('side').onclick = function (e) {
      var b = e.target.closest('button'); if (!b) return;
      you = +b.dataset.c; newGame();
    };
    newGame();
  }
